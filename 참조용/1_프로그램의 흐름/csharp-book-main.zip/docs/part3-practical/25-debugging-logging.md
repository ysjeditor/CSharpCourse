# 25장. 디버깅과 로깅

디버깅(Debugging)과 로깅(Logging)은 현대 소프트웨어 공학의 양대 관측성(Observability) 기둥으로, 소프트웨어의 동작을 이해하고 문제를 진단하며 시스템 상태를 모니터링하는 필수 실천 방법입니다. 디버깅은 개발 단계에서 코드의 실행 흐름과 상태를 대화형으로 탐색하여 논리적 오류를 발견하고 수정하는 과정이며, 로깅은 프로그램 실행 중 발생하는 이벤트와 상태 변화를 시계열로 기록하여 사후 분석과 실시간 모니터링을 가능하게 하는 메커니즘입니다.

**디버깅의 역사적 진화와 철학:**

"디버그(Debug)"라는 용어의 기원은 1947년 9월 9일로 거슬러 올라갑니다. 하버드 대학교의 Mark II 전자기계식 컴퓨터가 오작동을 일으켰을 때, Grace Hopper 대령과 그녀의 팀은 릴레이 스위치 사이에 끼어있는 실제 나방(moth)을 발견했습니다. 그들은 이 나방을 제거하면서 로그북에 "First actual case of bug being found"라고 기록하고 나방을 테이프로 붙여놓았습니다. 이 역사적인 로그북은 현재 스미소니언 박물관에 보관되어 있습니다.

그러나 디버깅의 개념 자체는 훨씬 더 오래되었습니다. 1843년 Ada Lovelace는 Charles Babbage의 해석 기관(Analytical Engine)에 대한 주석에서 이미 프로그램 오류의 가능성과 이를 찾아내는 과정의 중요성을 언급했습니다. 1950년대와 1960년대 초기 컴퓨터 시대에는 프로그래머들이 기계어 코드를 직접 검사하고 메모리 덤프(memory dump)를 분석하여 오류를 찾아야 했습니다.

현대적 의미의 대화형 디버깅(Interactive Debugging)은 1960년대 후반과 1970년대에 등장했습니다:

- **1967년**: John McCarthy의 LISP 시스템에 최초의 대화형 디버거 도입
- **1970년대**: UNIX의 `dbx`와 GNU의 `gdb` 디버거 개발
- **1980년대**: Turbo Pascal과 Turbo C의 통합 디버거가 대중화
- **1990년대**: Visual Studio의 강력한 GUI 디버거가 Windows 개발의 표준이 됨
- **2000년대**: Eclipse, IntelliJ IDEA 등 IDE 통합 디버거의 고도화
- **2010년대**: Chrome DevTools, VS Code 등 웹 기반 디버깅 도구의 부상

**디버깅의 경제적 가치:**

NIST(National Institute of Standards and Technology)의 2002년 연구에 따르면, 소프트웨어 버그는 미국 경제에 연간 약 595억 달러의 손실을 초래합니다. 이 연구는 또한 더 나은 테스팅과 디버깅 인프라가 이 비용의 약 3분의 1을 절감할 수 있다고 추정했습니다.

Cambridge University의 연구에 따르면:
- 개발자는 전체 개발 시간의 **50-75%**를 디버깅과 테스팅에 사용합니다
- 프로젝트 코드의 **약 20%**는 디버깅 지원 코드입니다 (로깅, 어설션, 진단 코드)
- 효과적인 디버깅 도구는 문제 해결 시간을 **40-60%** 단축시킵니다

Microsoft의 내부 연구에 따르면, Visual Studio의 IntelliTrace와 같은 고급 디버깅 기능은 재현하기 어려운 버그의 진단 시간을 평균 **70%** 단축시켰습니다.

**로깅의 역사적 발전:**

로깅의 개념은 항해 일지(ship's log)에서 유래했습니다. 선장은 항해 중 발생한 모든 중요한 사건을 시간순으로 기록했으며, 이는 나중에 문제 분석과 의사결정의 근거가 되었습니다. 컴퓨터 과학에서 로깅의 발전 과정은 다음과 같습니다:

- **1950-1960년대**: 천공 카드와 프린터를 통한 배치 처리 로그
- **1970년대**: UNIX `syslog` (1980년 표준화)의 등장으로 시스템 레벨 로깅 체계 확립
- **1980년대**: 애플리케이션 레벨 로깅의 필요성 인식
- **1996년**: Log4j의 등장으로 현대적 로깅 프레임워크 시대 개막
- **2000년대**: 분산 시스템의 확산으로 구조화된 로깅(Structured Logging) 필요성 증대
- **2010년대**: ELK Stack (Elasticsearch, Logstash, Kibana)과 같은 로그 집계 및 분석 도구의 대중화
- **2020년대**: OpenTelemetry와 분산 추적(Distributed Tracing)으로 진화

**구조화된 로깅의 혁명:**

전통적인 텍스트 기반 로깅은 인간이 읽기는 쉽지만 프로그래밍 방식으로 분석하기 어렵습니다. 2010년대 중반부터 등장한 **구조화된 로깅(Structured Logging)**은 로그 이벤트를 JSON이나 다른 구조화된 형식으로 저장하여, 검색, 필터링, 집계를 용이하게 만들었습니다.

```
전통적 로깅:
"2024-11-15 10:30:15 - User Alice logged in from 192.168.1.100"

구조화된 로깅:
{
  "timestamp": "2024-11-15T10:30:15Z",
  "level": "INFO",
  "event": "user_login",
  "user": "Alice",
  "ip_address": "192.168.1.100"
}
```

구조화된 로깅의 장점:
- **쿼리 가능**: `user="Alice" AND event="user_login"` 같은 검색 가능
- **집계 용이**: "지난 1시간 동안 로그인한 고유 사용자 수" 같은 통계 계산
- **자동화 친화적**: 알림, 모니터링, 보고서 생성 자동화
- **타입 안전성**: 필드의 타입이 보존됨

**관측성(Observability)의 세 기둥:**

현대 소프트웨어 공학에서 관측성은 세 가지 핵심 요소로 구성됩니다:

1. **로그(Logs)**: 이산적인 이벤트 기록 (이 장의 주제)
2. **메트릭(Metrics)**: 시계열 수치 데이터 (CPU 사용률, 요청 수 등)
3. **트레이스(Traces)**: 분산 시스템에서의 요청 흐름 추적

이 장에서는 로그와 디버깅에 초점을 맞추지만, 실무에서는 세 요소를 통합하여 시스템의 전체적인 상태를 이해해야 합니다.

**디버깅과 로깅의 상호보완성:**

디버깅과 로깅은 서로 다른 시나리오에서 강점을 발휘합니다:

| 측면 | 디버깅 | 로깅 |
|------|--------|------|
| **시점** | 개발/테스트 | 개발/테스트/프로덕션 |
| **상호작용** | 대화형, 실시간 | 비대화형, 사후 분석 |
| **오버헤드** | 높음 (실행 중지) | 낮음 (백그라운드) |
| **범위** | 단일 프로세스 | 분산 시스템 가능 |
| **재현성** | 같은 환경 필요 | 로그만 있으면 분석 가능 |
| **적용 대상** | 논리 오류, 알고리즘 | 성능, 보안, 운영 이슈 |

## 이 장에서 배울 내용

이 장을 통해 독자 여러분은 디버깅과 로깅의 이론적 기반부터 실무 적용까지 포괄적으로 습득하게 됩니다:

- **디버깅의 이론과 실천**: Grace Hopper의 역사적 사건에서 현대 IDE까지의 진화 과정, 디버거의 내부 동작 원리, 중단점의 작동 메커니즘, 그리고 심볼 파일(PDB)과 소스 맵의 역할을 깊이 있게 이해합니다.

- **Visual Studio Code 디버거 마스터하기**: 중단점의 다양한 유형(조건부, 로그 포인트, 적중 횟수), 변수 검사와 조사식의 활용, 호출 스택 추적과 프레임 분석, 그리고 디버그 콘솔을 통한 대화형 탐색 기법을 실전 예제와 함께 학습합니다.

- **로깅 아키텍처와 설계 패턴**: 로깅의 역사적 발전, UNIX syslog에서 현대 구조화된 로깅까지의 진화, 로그 레벨의 의미론과 적용 원칙, 그리고 Serilog, NLog, log4net의 아키텍처 비교를 통해 로깅 프레임워크의 본질을 이해합니다.

- **Microsoft.Extensions.Logging 생태계**: .NET의 표준 로깅 추상화 계층, 의존성 주입을 통한 로거 구성, 로깅 프로바이더(Provider) 패턴, 로그 범위(Scope)와 컨텍스트 전파, 그리고 성능 최적화 기법을 실무 시나리오를 통해 체득합니다.

- **구조화된 로깅의 혁명**: 전통적 텍스트 로깅의 한계, 구조화된 로깅의 철학과 이점, 메시지 템플릿과 속성 추출, Elasticsearch나 Splunk 같은 로그 집계 도구와의 통합, 그리고 분산 추적(Distributed Tracing)과의 연계를 학습합니다.

- **프로덕션 환경의 관측성**: 로그 레벨 동적 조정, 로그 필터링과 샘플링 전략, 민감 정보 마스킹과 보안, 로그 로테이션과 보관 정책, 그리고 비용 최적화 전략을 배웁니다.

**학습 목표:**

- Visual Studio Code 디버거의 고급 기능을 활용한 효율적 문제 해결
- 디버거의 내부 메커니즘과 성능 특성 이해
- 구조화된 로깅을 통한 운영 가능한(Operational) 시스템 설계
- Microsoft.Extensions.Logging 아키텍처와 확장 메커니즘 습득
- 환경별 로깅 전략 수립과 관측성(Observability) 문화 구축
- 디버깅과 로깅을 통한 지속적 개선(Continuous Improvement) 실천

---

## 25.1 Visual Studio Code 디버거 사용

Visual Studio Code는 Language Server Protocol(LSP)과 Debug Adapter Protocol(DAP)을 기반으로 한 강력하고 확장 가능한 디버깅 인프라를 제공합니다. 2015년 Microsoft가 오픈소스로 공개한 VS Code의 디버깅 아키텍처는 언어에 독립적인 디버거 프론트엔드와 각 언어별 디버그 어댑터를 분리하여, 일관된 사용자 경험을 유지하면서도 다양한 런타임을 지원할 수 있게 설계되었습니다.

**디버거의 아키텍처와 작동 원리:**

VS Code 디버거의 계층적 아키텍처는 다음과 같이 구성됩니다:

```
┌─────────────────────────────────────────────────────────┐
│ VS Code UI (사용자 인터페이스)                            │
│ • 중단점 표시, 변수 창, 디버그 콘솔                        │
│ • 단계 실행 버튼, 호출 스택 뷰                            │
└─────────────────────────────────────────────────────────┘
                         ↓ DAP (JSON-RPC)
┌─────────────────────────────────────────────────────────┐
│ Debug Adapter (디버그 어댑터)                             │
│ • C#: .NET Core Debugger (vsdbg)                        │
│ • Node.js, Python, Go 등 언어별 어댑터                   │
└─────────────────────────────────────────────────────────┘
                         ↓
┌─────────────────────────────────────────────────────────┐
│ Runtime Debugger Interface (런타임 디버거)                │
│ • .NET: CoreCLR Debugging APIs                          │
│ • Native: GDB/LLDB                                      │
└─────────────────────────────────────────────────────────┘
                         ↓
┌─────────────────────────────────────────────────────────┐
│ Target Process (대상 프로세스)                            │
│ • 실행 중인 애플리케이션                                   │
│ • 메모리, 스레드, 스택 프레임                              │
└─────────────────────────────────────────────────────────┘
```

**Debug Adapter Protocol (DAP):**

Microsoft가 2018년에 표준화한 DAP는 디버거 UI와 디버그 엔진 간의 통신 프로토콜입니다. JSON-RPC 기반의 메시지 교환으로 다음 작업을 수행합니다:

- **초기화**: 디버거 기능 협상 (중단점 유형, 예외 처리 등)
- **설정**: 중단점 설정, 예외 필터 구성
- **실행 제어**: 시작, 계속, 일시 중지, 중지, 단계 실행
- **데이터 검사**: 변수, 스택 프레임, 스코프 조회
- **평가**: 표현식 계산, 조사식 업데이트

**심볼 파일(Symbol Files)과 디버깅 정보:**

.NET 애플리케이션을 디버깅하려면 **PDB 파일**(Program Database)이 필요합니다. PDB 파일은 컴파일 시 생성되며 다음 정보를 포함합니다:

- **소스 코드 위치**: IL 명령어와 소스 코드 줄 번호의 매핑
- **변수 이름**: 컴파일러가 최적화로 제거하지 않은 로컬 변수
- **타입 정보**: 클래스, 구조체, 열거형의 메타데이터
- **메서드 정보**: 시그니처, 매개변수 이름

.NET Core부터는 **Portable PDB** 형식을 사용하여 크로스 플랫폼 디버깅을 지원합니다:

```xml
<PropertyGroup>
  <DebugType>portable</DebugType>  <!-- Portable PDB -->
  <!-- 또는 -->
  <DebugType>full</DebugType>      <!-- Windows PDB -->
  <DebugType>embedded</DebugType>  <!-- DLL에 포함 -->
</PropertyGroup>
```

**디버거의 성능 특성과 오버헤드:**

디버그 모드 실행은 최적화된 릴리스 모드에 비해 상당한 오버헤드를 동반합니다:

| 특성 | Debug 모드 | Release 모드 |
|------|-----------|-------------|
| **실행 속도** | 2-10배 느림 | 최적화됨 |
| **메모리 사용** | 더 높음 | 최적화됨 |
| **컴파일러 최적화** | 비활성화 | 인라이닝, 데드 코드 제거 |
| **변수 수명** | 연장됨 (검사 가능) | 필요 시까지만 |
| **코드 재배치** | 없음 (소스 일치) | 성능 최적화 |

**디버거의 주요 개념과 용어:**

- **중단점(Breakpoint)**: 프로그램 실행을 일시 중지할 코드 위치를 지정합니다. 내부적으로 디버거는 해당 위치의 명령어를 특수한 인터럽트 명령어로 교체하거나 (하드웨어 중단점) 조건을 런타임에 검사합니다 (소프트웨어 중단점).

- **단계 실행(Stepping)**: 코드를 제어된 방식으로 한 줄씩 실행합니다. Step Over는 함수 호출을 단일 단계로, Step Into는 함수 내부로 진입, Step Out은 현재 함수를 끝까지 실행합니다.

- **호출 스택(Call Stack)**: 현재 실행 위치에 도달하기까지의 함수 호출 체인입니다. 각 스택 프레임은 매개변수, 로컬 변수, 반환 주소를 포함합니다.

- **스코프(Scope)**: 변수의 가시성 범위입니다. Local (현재 함수), Closure (캡처된 변수), Global (정적 필드) 등이 있습니다.

- **조사식(Watch Expression)**: 특정 표현식의 값을 지속적으로 평가하고 모니터링합니다. 조사식은 매 중단마다 재평가되어 값 변화를 추적합니다.

**Just-In-Time (JIT) 디버깅:**

.NET의 JIT 컴파일러는 런타임에 IL(Intermediate Language) 코드를 네이티브 기계어로 변환합니다. 디버그 모드에서 JIT는:

- 더 많은 디버깅 정보를 생성합니다 (시퀀스 포인트, 변수 위치)
- 최적화를 억제합니다 (변수가 레지스터 대신 스택에 유지)
- 인라이닝을 제한합니다 (Step Into가 작동하도록)

`[MethodImpl(MethodImplOptions.AggressiveInlining)]`과 같은 속성은 디버그 모드에서도 무시될 수 있습니다.

### 25.1.1 중단점 (Breakpoints)

중단점은 디버깅의 가장 기본적이면서도 강력한 도구로, 1960년대 초기 디버거부터 현재까지 디버깅의 핵심 메커니즘으로 자리잡고 있습니다. 중단점의 개념은 간단하지만, 그 구현과 활용에는 깊은 기술적 통찰이 필요합니다.

**중단점의 작동 원리:**

중단점이 작동하는 방식을 이해하면 더 효과적으로 활용할 수 있습니다. 중단점은 크게 두 가지 유형으로 구현됩니다:

**1. 소프트웨어 중단점 (Software Breakpoint):**

가장 일반적인 형태로, 디버거가 해당 위치의 명령어를 특수한 인터럽트 명령어로 교체합니다:

```
원본 코드:
int result = Calculate(x, y);

IL 코드 (중단점 없음):
ldarg.0        // this 로드
ldarg.1        // x 로드
ldarg.2        // y 로드
call Calculate // 메서드 호출

IL 코드 (중단점 설정):
nop            // 디버거가 여기에 브레이크 인스트럭션 삽입
ldarg.0
ldarg.1
ldarg.2
call Calculate
```

프로그램이 브레이크 인스트럭션에 도달하면 CPU가 예외를 발생시키고, 운영체제가 디버거에게 제어를 넘깁니다. 디버거는 프로세스를 일시 중지하고 사용자에게 상태를 표시합니다.

**2. 하드웨어 중단점 (Hardware Breakpoint):**

CPU의 디버그 레지스터를 사용하여 특정 메모리 주소 접근을 감시합니다. x86/x64 아키텍처는 4개의 하드웨어 중단점을 지원합니다. 장점:
- 코드 수정 없이 중단점 설정 가능
- 읽기 전용 메모리에도 설정 가능
- 데이터 중단점 (특정 변수 값 변경 시 중단) 구현 가능

단점:
- 개수 제한 (보통 4개)
- 플랫폼 의존적

**중단점의 성능 영향:**

- **비활성 중단점**: 거의 영향 없음 (메타데이터만 저장)
- **활성 소프트웨어 중단점**: 해당 줄 실행 시에만 짧은 오버헤드 (마이크로초 단위)
- **조건부 중단점**: 조건 평가 비용 추가 (밀리초 단위, 조건 복잡도에 따라)
- **로그 포인트**: 디스크 I/O 오버헤드 (수십 밀리초)

**중단점 설정과 관리:**

VS Code에서 중단점을 설정하는 다양한 방법:

```csharp
using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace DebuggingExample
{
    // 디버깅 대상 클래스
    public class OrderProcessor
    {
        private readonly List<Order> _orders = new();
        
        public void ProcessOrders()
        {
            // 중단점 1: 메서드 진입점
            // 목적: 메서드가 호출되었는지 확인
            Console.WriteLine("주문 처리 시작");
            
            for (int i = 0; i < _orders.Count; i++)
            {
                // 중단점 2: 루프 내부
                // 목적: 각 반복의 상태 검사
                var order = _orders[i];
                
                // 중단점 3: 조건부 검사 위치
                // 조건: order.Amount > 1000000
                // 목적: 고액 주문만 검사
                if (order.Amount > 1000000)
                {
                    Console.WriteLine($"고액 주문: {order.Id}");
                }
                
                try
                {
                    // 중단점 4: 핵심 로직
                    ValidateOrder(order);
                    ProcessPayment(order);
                    
                    // 중단점 5: 성공 경로
                    order.Status = OrderStatus.Completed;
                }
                catch (Exception ex)
                {
                    // 중단점 6: 예외 처리
                    // 자동 중단: "Throw되는 모든 예외에서 중단" 옵션
                    order.Status = OrderStatus.Failed;
                    LogError(order, ex);
                }
            }
            
            // 중단점 7: 메서드 종료 전
            // 목적: 최종 상태 확인
            Console.WriteLine($"처리 완료: {_orders.Count}건");
        }
        
        // 디버깅 헬퍼: 조건부 컴파일
        [Conditional("DEBUG")]
        private void LogDebugInfo(Order order)
        {
            // 이 메서드는 DEBUG 모드에서만 컴파일됨
            Console.WriteLine($"Debug: Order {order.Id}, Amount: {order.Amount}");
        }
        
        private void ValidateOrder(Order order)
        {
            if (order.Amount <= 0)
                throw new ArgumentException("잘못된 금액");
        }
        
        private void ProcessPayment(Order order)
        {
            // 결제 처리 시뮬레이션
            System.Threading.Thread.Sleep(100);
        }
        
        private void LogError(Order order, Exception ex)
        {
            Console.WriteLine($"오류: Order {order.Id} - {ex.Message}");
        }
    }
    
    public class Order
    {
        public int Id { get; set; }
        public decimal Amount { get; set; }
        public OrderStatus Status { get; set; }
    }
    
    public enum OrderStatus
    {
        Pending,
        Completed,
        Failed
    }
}
```

**중단점 설정 워크플로우:**

1. **기본 중단점 설정**:
   - 줄 번호 왼쪽 여백(gutter)을 클릭
   - 빨간 점이 표시되면 중단점 활성화
   - F9 키로 현재 줄에 중단점 토글

2. **중단점 비활성화** (삭제하지 않고 일시 해제):
   - 중단점을 우클릭 → "비활성화"
   - 회색 원으로 표시됨
   - 나중에 다시 활성화 가능

3. **모든 중단점 관리**:
   - Debug 사이드바의 "중단점" 패널
   - 체크박스로 개별 활성화/비활성화
   - 휴지통 아이콘으로 전체 삭제

**중단점의 고급 기능:**

**1. 적중 횟수 (Hit Count):**

중단점이 특정 횟수만큼 지나간 후에 중단합니다. 반복문에서 N번째 반복에만 관심이 있을 때 유용합니다:

```csharp
for (int i = 0; i < 10000; i++)
{
    // 중단점 설정 → 우클릭 → "중단점 편집"
    // 적중 횟수: "= 5000" 입력
    // 5000번째 반복에서만 중단됨
    ProcessData(i);
}
```

적중 횟수 조건:
- `= 5`: 정확히 5번째 적중 시
- `>= 10`: 10번째 이후 매번
- `% 100 = 0`: 100번마다

**2. 함수 중단점 (Function Breakpoint):**

특정 함수 이름으로 중단점 설정 (소스 코드 위치 불필요):

```
Debug 패널 → "중단점" → "+" → "함수 중단점"
함수 이름 입력: "OrderProcessor.ProcessPayment"
```

동적으로 로드되는 코드나 리플렉션으로 호출되는 메서드에 유용합니다.

**3. 데이터 중단점 (Data Breakpoint) - C# 제한적 지원:**

특정 변수의 값이 변경될 때 중단합니다. x86/x64 네이티브 코드에서는 하드웨어 중단점으로 구현되지만, .NET 관리 코드에서는 제한적입니다.

**디버그 제어 명령과 단축키:**

| 명령 | 단축키 | 설명 | 내부 동작 |
|------|--------|------|----------|
| **Continue** | F5 | 다음 중단점까지 실행 | 프로세스 재개 |
| **Step Over** | F10 | 현재 줄 실행, 함수 내부 진입 안 함 | 함수 호출 시 임시 중단점 설정 후 계속 |
| **Step Into** | F11 | 함수 내부로 진입 | 다음 IL 명령어에서 중단 |
| **Step Out** | Shift+F11 | 현재 함수 끝까지 실행 | 반환 주소에 임시 중단점 |
| **Restart** | Ctrl+Shift+F5 | 디버깅 세션 재시작 | 프로세스 종료 후 재시작 |
| **Stop** | Shift+F5 | 디버깅 종료 | 프로세스 강제 종료 |

**Step Over vs Step Into의 차이:**

```csharp
void MainMethod()
{
    int x = 10;
    int result = Calculate(x);  // 여기서 F10 (Step Over)
    Console.WriteLine(result);  // 다음 줄로 이동
}

int Calculate(int value)
{
    // F11 (Step Into)를 누르면 여기로 진입
    return value * 2;
}
```

**예외 발생 시 자동 중단:**

```
Debug 패널 → 톱니바퀴 아이콘 → "예외 설정"

옵션:
- "모든 예외": 모든 throw 문에서 중단 (catch 전)
- "처리되지 않은 예외": catch되지 않은 예외만
- "특정 예외": System.ArgumentException 등 선택적
```

이는 "숨겨진" 예외를 발견하는 데 매우 유용합니다:

```csharp
try
{
    // 예외가 발생하지만 catch로 숨겨짐
    ProcessData();
}
catch (Exception ex)
{
    // 로그만 남기고 계속 실행
    // 문제: 예외의 진짜 원인을 놓칠 수 있음
    Console.WriteLine("오류 발생");
}
```

"모든 예외에서 중단" 옵션을 활성화하면 catch 전에 중단되어 예외의 정확한 발생 지점을 확인할 수 있습니다.

**중단점 활용 모범 사례:**

1. **전략적 배치**: 
   - 알고리즘의 핵심 결정 지점
   - 상태 변경이 발생하는 곳
   - 예외가 발생할 가능성이 있는 곳

2. **최소화 원칙**:
   - 너무 많은 중단점은 디버깅을 방해
   - 문제 영역을 좁혀가며 점진적으로 추가

3. **조건부 중단점 활용**:
   - 반복문에서 특정 조건만 검사
   - 성능 영향 인지하고 사용

4. **로그 포인트 우선 고려**:
   - 실행 흐름을 추적할 때는 로그 포인트가 더 효율적
   - 중단 없이 정보 수집 가능

5. **심볼 파일 확인**:
   - PDB 파일이 없으면 중단점이 "검증되지 않음" 상태로 표시
   - 빌드 후 bin/Debug 디렉터리에 .pdb 파일 존재 확인

### 25.1.2 변수 검사

디버거가 중단점에서 멈추면, 현재 범위(scope)의 모든 변수 값을 확인할 수 있습니다.

**변수 확인 방법:**

1. **변수 창(Variables Panel)**: 
   - 좌측 디버그 사이드바의 "변수" 섹션에서 로컬 변수, 전역 변수 확인
   - 객체를 확장하여 내부 속성 탐색

2. **호버 검사(Hover Inspection)**:
   - 변수 위에 마우스를 올리면 현재 값 표시
   - 복잡한 객체는 팝업에서 확장 가능

3. **조사식(Watch)**:
   - 특정 표현식을 추가하여 지속적으로 모니터링
   - 변수뿐만 아니라 복잡한 표현식도 평가 가능

**변수 검사 예제:**

```csharp
using System;
using System.Collections.Generic;

class Product
{
    public string Name { get; set; }
    public decimal Price { get; set; }
    public int Stock { get; set; }
}

class Program
{
    static void Main()
    {
        // 중단점을 설정하고 각 단계의 변수 상태를 확인해봅시다
        var products = new List<Product>
        {
            new Product { Name = "노트북", Price = 1500000, Stock = 10 },
            new Product { Name = "마우스", Price = 50000, Stock = 50 },
            new Product { Name = "키보드", Price = 120000, Stock = 30 }
        };
        
        // 중단점: products 리스트 내용 확인
        decimal totalValue = 0;
        
        foreach (var product in products)
        {
            // 중단점: 각 product의 속성 확인
            decimal productValue = product.Price * product.Stock;
            totalValue += productValue;
            
            Console.WriteLine($"{product.Name}: {productValue:C}");
        }
        
        // 중단점: 최종 totalValue 확인
        Console.WriteLine($"총 재고 가치: {totalValue:C}");
    }
}
```

**변수 창에서 확인할 수 있는 정보:**

- **로컬 변수(Locals)**: 현재 메서드의 모든 지역 변수
- **매개변수(Parameters)**: 메서드에 전달된 인수
- **필드(Fields)**: 클래스의 멤버 변수
- **속성(Properties)**: 객체의 속성 값
- **컬렉션 요소**: 배열, 리스트, 딕셔너리 등의 내용

**디버그 콘솔(Debug Console):**

디버그 콘솔에서 C# 표현식을 직접 평가할 수 있습니다:

```
// 디버그 콘솔에서 실행 가능한 표현식 예시
products.Count
products[0].Name
totalValue * 1.1m  // 10% 마진 계산
products.Where(p => p.Stock < 20).Count()
```

### 25.1.3 조건부 중단점

모든 실행에서 멈추는 일반 중단점과 달리, 조건부 중단점은 특정 조건을 만족할 때만 실행을 중지합니다. 이는 반복문 안에서 특정 값을 가진 경우에만 디버깅하고 싶을 때 매우 유용합니다.

**조건부 중단점 설정:**

1. 일반 중단점을 설정합니다 (빨간 점)
2. 중단점을 우클릭하고 "중단점 편집(Edit Breakpoint)" 선택
3. 조건식을 입력합니다

**조건부 중단점 종류:**

**1. 표현식 조건(Expression Condition):**

특정 조건이 참일 때만 중단됩니다.

```csharp
using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        var numbers = new List<int>();
        
        // 1부터 100까지 숫자 생성
        for (int i = 1; i <= 100; i++)
        {
            numbers.Add(i);
            
            // 중단점: 조건 "i == 50" 설정
            // i가 50일 때만 멈춥니다
            ProcessNumber(i);
        }
    }
    
    static void ProcessNumber(int number)
    {
        // 중단점: 조건 "number > 90" 설정
        // 90보다 큰 값에서만 멈춥니다
        Console.WriteLine($"처리 중: {number}");
    }
}
```

**2. 적중 횟수(Hit Count):**

중단점이 특정 횟수만큼 실행된 후에 중단됩니다.

```csharp
using System;

class Program
{
    static void Main()
    {
        // 중단점: 적중 횟수 "= 10" 설정
        // 10번째 반복에서만 멈춥니다
        for (int i = 0; i < 100; i++)
        {
            ProcessData(i);
        }
    }
    
    static void ProcessData(int value)
    {
        Console.WriteLine($"데이터 처리: {value}");
    }
}
```

**3. 로그 포인트(Log Point):**

프로그램 실행을 중지하지 않고 메시지만 출력합니다. 중단점 대신 다이아몬드 모양 아이콘이 표시됩니다.

```csharp
using System;

class Program
{
    static void Main()
    {
        for (int i = 0; i < 10; i++)
        {
            // 로그 포인트: "현재 i 값: {i}"
            // 중단하지 않고 콘솔에 메시지만 출력
            int result = Calculate(i);
            Console.WriteLine($"결과: {result}");
        }
    }
    
    static int Calculate(int value)
    {
        return value * value;
    }
}
```

**실전 활용 예제:**

```csharp
using System;
using System.Collections.Generic;
using System.Linq;

class Order
{
    public int OrderId { get; set; }
    public string CustomerName { get; set; }
    public decimal Amount { get; set; }
    public string Status { get; set; }
}

class Program
{
    static void Main()
    {
        var orders = GenerateOrders();
        
        foreach (var order in orders)
        {
            // 조건부 중단점: order.Amount > 1000000
            // 백만 원 이상 주문만 검사
            ProcessOrder(order);
        }
        
        // 중단점: Status가 "실패"인 주문 개수 확인
        var failedOrders = orders.Where(o => o.Status == "실패").ToList();
        Console.WriteLine($"실패한 주문: {failedOrders.Count}개");
    }
    
    static void ProcessOrder(Order order)
    {
        // 조건부 중단점: order.Status == "실패"
        // 실패한 주문에서만 멈춰서 원인 파악
        try
        {
            if (order.Amount > 2000000)
            {
                throw new Exception("금액 초과");
            }
            
            order.Status = "성공";
        }
        catch (Exception ex)
        {
            order.Status = "실패";
            Console.WriteLine($"주문 {order.OrderId} 실패: {ex.Message}");
        }
    }
    
    static List<Order> GenerateOrders()
    {
        var random = new Random();
        var orders = new List<Order>();
        
        for (int i = 1; i <= 50; i++)
        {
            orders.Add(new Order
            {
                OrderId = i,
                CustomerName = $"고객{i}",
                Amount = random.Next(100000, 3000000),
                Status = "대기"
            });
        }
        
        return orders;
    }
}
```

**조건부 중단점 활용 팁:**

- **성능 고려**: 조건을 평가하는 데도 시간이 걸리므로 복잡한 조건은 피합니다
- **부작용 주의**: 조건식에서 변수를 변경하지 않도록 주의합니다
- **로그 포인트 활용**: 실행 흐름을 추적하되 중단하고 싶지 않을 때 유용합니다
- **임시 비활성화**: 중단점을 삭제하지 않고 우클릭으로 비활성화/활성화 가능합니다

---

## 25.2 로깅

로깅은 프로그램 실행 중 발생하는 이벤트, 상태 변화, 오류 등을 기록하는 프로세스입니다. 개발 단계에서는 디버깅을, 프로덕션 환경에서는 모니터링과 문제 진단을 가능하게 합니다.

**로깅의 핵심 원칙:**

1. **적절한 상세도**: 너무 많으면 노이즈, 너무 적으면 정보 부족
2. **구조화된 정보**: 검색과 분석이 가능하도록 일관된 형식 유지
3. **성능 고려**: 로깅이 애플리케이션 성능에 미치는 영향 최소화
4. **보안**: 민감한 정보(비밀번호, 개인정보)를 로그에 기록하지 않음
5. **회전 정책**: 로그 파일이 무한정 커지지 않도록 관리

### 25.2.1 Console.WriteLine vs 로깅 프레임워크

초보 개발자들은 디버깅과 정보 출력을 위해 `Console.WriteLine`을 자주 사용합니다. 간단한 프로그램에서는 문제가 없지만, 실무 애플리케이션에서는 여러 한계가 있습니다.

**Console.WriteLine의 한계:**

```csharp
using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("프로그램 시작");
        
        try
        {
            ProcessData();
            Console.WriteLine("데이터 처리 완료");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"오류 발생: {ex.Message}");
        }
        
        Console.WriteLine("프로그램 종료");
    }
    
    static void ProcessData()
    {
        Console.WriteLine("데이터 처리 중...");
        // 실제 처리 로직
    }
}
```

**문제점:**

1. **레벨 구분 없음**: 정보성 메시지, 경고, 오류가 모두 같은 방식으로 출력됩니다
2. **파일 저장 불가**: 콘솔에만 출력되어 나중에 분석할 수 없습니다
3. **필터링 어려움**: 특정 종류의 메시지만 보거나 끌 수 없습니다
4. **타임스탬프 없음**: 언제 발생했는지 알 수 없습니다
5. **구조화 부족**: 검색과 분석이 어렵습니다
6. **프로덕션 부적합**: 서비스 애플리케이션에서는 콘솔이 없을 수 있습니다

**로깅 프레임워크의 장점:**

```csharp
using System;
using Microsoft.Extensions.Logging;

class Program
{
    // 로깅 프레임워크는 다음과 같은 기능을 제공합니다:
    // - 로그 레벨 (Trace, Debug, Information, Warning, Error, Critical)
    // - 다양한 출력 대상 (콘솔, 파일, 데이터베이스, 클라우드)
    // - 타임스탬프와 컨텍스트 정보 자동 추가
    // - 환경별 설정 (개발/테스트/프로덕션)
    // - 구조화된 로깅 (검색과 필터링 용이)
    // - 비동기 로깅 (성능 최적화)
}
```

**비교 예제:**

```csharp
// ❌ Console.WriteLine 방식
Console.WriteLine("사용자 홍길동이 로그인했습니다");
Console.WriteLine($"오류: 파일을 찾을 수 없음 - {filePath}");

// ✅ 로깅 프레임워크 방식
logger.LogInformation("사용자 {UserName}이 로그인했습니다", "홍길동");
logger.LogError("파일을 찾을 수 없음: {FilePath}", filePath);
```

로깅 프레임워크는 다음 섹션에서 자세히 다룹니다.

### 25.2.2 Microsoft.Extensions.Logging

`Microsoft.Extensions.Logging`은 .NET의 표준 로깅 추상화(abstraction)입니다. 이를 사용하면 로깅 프레임워크에 독립적인 코드를 작성할 수 있으며, 나중에 실제 로깅 구현체(Serilog, NLog 등)를 쉽게 교체할 수 있습니다.

**설치:**

```bash
# .NET 프로젝트에 로깅 패키지 추가
dotnet add package Microsoft.Extensions.Logging
dotnet add package Microsoft.Extensions.Logging.Console
```

**기본 설정과 사용:**

```csharp
using System;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;

class Program
{
    static void Main()
    {
        // 1. 서비스 컬렉션 생성 (의존성 주입 컨테이너)
        var serviceProvider = new ServiceCollection()
            .AddLogging(builder =>
            {
                builder
                    .AddConsole()  // 콘솔 로깅 추가
                    .SetMinimumLevel(LogLevel.Debug);  // 최소 로그 레벨 설정
            })
            .BuildServiceProvider();
        
        // 2. 로거 가져오기
        var logger = serviceProvider.GetRequiredService<ILogger<Program>>();
        
        // 3. 로깅 사용
        logger.LogInformation("애플리케이션 시작");
        
        try
        {
            ProcessOrders(logger);
            logger.LogInformation("주문 처리 완료");
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "주문 처리 중 오류 발생");
        }
        
        logger.LogInformation("애플리케이션 종료");
    }
    
    static void ProcessOrders(ILogger logger)
    {
        logger.LogDebug("주문 처리 시작");
        
        // 구조화된 로깅 - 변수를 템플릿으로 전달
        string customerName = "홍길동";
        int orderCount = 5;
        logger.LogInformation(
            "고객 {CustomerName}의 주문 {OrderCount}건 처리",
            customerName,
            orderCount
        );
        
        // 경고 로그
        if (orderCount > 10)
        {
            logger.LogWarning(
                "주문 수가 많습니다: {OrderCount}건",
                orderCount
            );
        }
    }
}
```

**실행 결과:**

```
info: Program[0]
      애플리케이션 시작
dbug: Program[0]
      주문 처리 시작
info: Program[0]
      고객 홍길동의 주문 5건 처리
info: Program[0]
      주문 처리 완료
info: Program[0]
      애플리케이션 종료
```

**구조화된 로깅 (Structured Logging):**

문자열 보간 대신 템플릿과 매개변수를 사용하면 로그를 구조화된 데이터로 저장할 수 있습니다.

```csharp
using System;
using Microsoft.Extensions.Logging;

class OrderProcessor
{
    private readonly ILogger<OrderProcessor> _logger;
    
    public OrderProcessor(ILogger<OrderProcessor> logger)
    {
        _logger = logger;
    }
    
    public void ProcessOrder(int orderId, string customerName, decimal amount)
    {
        // ❌ 나쁜 예: 문자열 보간
        _logger.LogInformation($"주문 처리: {orderId}, 고객: {customerName}, 금액: {amount}");
        
        // ✅ 좋은 예: 구조화된 로깅
        _logger.LogInformation(
            "주문 처리 시작 - OrderId: {OrderId}, Customer: {CustomerName}, Amount: {Amount}",
            orderId,
            customerName,
            amount
        );
        
        // 이렇게 하면 나중에 다음과 같이 검색 가능:
        // - OrderId가 1234인 모든 로그
        // - Amount가 100만원 이상인 주문 로그
        // - 특정 CustomerName의 모든 활동
    }
}
```

**로그 범위 (Log Scopes):**

관련된 로그를 그룹화하여 컨텍스트를 추가할 수 있습니다.

```csharp
using System;
using Microsoft.Extensions.Logging;

class UserService
{
    private readonly ILogger<UserService> _logger;
    
    public UserService(ILogger<UserService> logger)
    {
        _logger = logger;
    }
    
    public void ProcessUserRequest(string userId)
    {
        // 범위 시작 - 이 블록 안의 모든 로그에 UserId 추가
        using (_logger.BeginScope("UserId: {UserId}", userId))
        {
            _logger.LogInformation("사용자 요청 처리 시작");
            
            ValidateUser(userId);
            ProcessData(userId);
            
            _logger.LogInformation("사용자 요청 처리 완료");
        }
    }
    
    private void ValidateUser(string userId)
    {
        _logger.LogDebug("사용자 검증 중");
        // 검증 로직
    }
    
    private void ProcessData(string userId)
    {
        _logger.LogDebug("데이터 처리 중");
        // 처리 로직
    }
}
```

**파일 로깅 추가:**

```bash
# 파일 로깅 패키지 설치
dotnet add package Serilog.Extensions.Logging.File
```

```csharp
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;

var serviceProvider = new ServiceCollection()
    .AddLogging(builder =>
    {
        builder
            .AddConsole()  // 콘솔 출력
            .AddFile("logs/app-{Date}.txt");  // 파일 출력 (일별 로테이션)
    })
    .BuildServiceProvider();
```

### 25.2.3 로그 레벨

로그 레벨은 메시지의 중요도와 상세도를 나타냅니다. 적절한 로그 레벨을 사용하면 환경에 따라 필요한 정보만 기록할 수 있습니다.

**로그 레벨 종류 (낮음 → 높음):**

| 레벨 | 값 | 용도 | 사용 예시 |
|------|----|----|---------|
| **Trace** | 0 | 매우 상세한 추적 정보 | 함수 진입/종료, 루프 반복 |
| **Debug** | 1 | 디버깅 정보 | 변수 값, 중간 계산 결과 |
| **Information** | 2 | 일반 정보성 메시지 | 요청 처리 완료, 상태 변경 |
| **Warning** | 3 | 경고 (문제는 아니지만 주의) | 임계값 근접, 권장하지 않는 사용 |
| **Error** | 4 | 오류 (기능 실패) | 예외 발생, 작업 실패 |
| **Critical** | 5 | 치명적 오류 (시스템 장애) | 서비스 중단, 데이터 손실 |
| **None** | 6 | 로깅 비활성화 | - |

**로그 레벨 사용 예제:**

```csharp
using System;
using Microsoft.Extensions.Logging;

class PaymentService
{
    private readonly ILogger<PaymentService> _logger;
    
    public PaymentService(ILogger<PaymentService> logger)
    {
        _logger = logger;
    }
    
    public bool ProcessPayment(string userId, decimal amount)
    {
        // Trace: 매우 상세한 추적 (개발 시에만)
        _logger.LogTrace(
            "ProcessPayment 메서드 진입 - UserId: {UserId}, Amount: {Amount}",
            userId,
            amount
        );
        
        // Debug: 디버깅 정보
        _logger.LogDebug("결제 유효성 검증 시작");
        
        if (amount <= 0)
        {
            // Warning: 잠재적 문제
            _logger.LogWarning(
                "잘못된 결제 금액 - UserId: {UserId}, Amount: {Amount}",
                userId,
                amount
            );
            return false;
        }
        
        // Information: 정상적인 흐름의 중요 이벤트
        _logger.LogInformation(
            "결제 처리 시작 - UserId: {UserId}, Amount: {Amount:C}",
            userId,
            amount
        );
        
        try
        {
            // 결제 처리 로직
            if (amount > 1000000)
            {
                // Warning: 주의가 필요한 상황
                _logger.LogWarning(
                    "고액 결제 감지 - UserId: {UserId}, Amount: {Amount:C}",
                    userId,
                    amount
                );
            }
            
            // 결제 성공
            _logger.LogInformation(
                "결제 완료 - UserId: {UserId}, Amount: {Amount:C}",
                userId,
                amount
            );
            
            return true;
        }
        catch (PaymentException ex)
        {
            // Error: 복구 가능한 오류
            _logger.LogError(
                ex,
                "결제 실패 - UserId: {UserId}, Amount: {Amount:C}",
                userId,
                amount
            );
            return false;
        }
        catch (Exception ex)
        {
            // Critical: 치명적 오류
            _logger.LogCritical(
                ex,
                "결제 시스템 치명적 오류 - UserId: {UserId}",
                userId
            );
            throw;
        }
    }
}

class PaymentException : Exception
{
    public PaymentException(string message) : base(message) { }
}
```

**환경별 로그 레벨 설정:**

```csharp
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;

class Program
{
    static void Main()
    {
        // 환경 변수로 로그 레벨 결정
        string environment = Environment.GetEnvironmentVariable("ENVIRONMENT") ?? "Development";
        
        var serviceProvider = new ServiceCollection()
            .AddLogging(builder =>
            {
                builder.AddConsole();
                
                // 환경별 로그 레벨 설정
                if (environment == "Development")
                {
                    // 개발: 모든 로그 출력
                    builder.SetMinimumLevel(LogLevel.Trace);
                }
                else if (environment == "Staging")
                {
                    // 스테이징: Debug 이상
                    builder.SetMinimumLevel(LogLevel.Debug);
                }
                else // Production
                {
                    // 프로덕션: Information 이상만
                    builder.SetMinimumLevel(LogLevel.Information);
                }
                
                // 특정 네임스페이스의 로그 레벨 조정
                builder.AddFilter("Microsoft", LogLevel.Warning);  // Microsoft 관련은 Warning 이상만
                builder.AddFilter("System", LogLevel.Warning);      // System 관련은 Warning 이상만
            })
            .BuildServiceProvider();
        
        var logger = serviceProvider.GetRequiredService<ILogger<Program>>();
        
        logger.LogTrace("Trace 메시지 - 매우 상세");
        logger.LogDebug("Debug 메시지 - 디버깅");
        logger.LogInformation("Information 메시지 - 일반 정보");
        logger.LogWarning("Warning 메시지 - 경고");
        logger.LogError("Error 메시지 - 오류");
        logger.LogCritical("Critical 메시지 - 치명적");
    }
}
```

**로그 레벨 선택 가이드:**

```csharp
using Microsoft.Extensions.Logging;

class LoggingGuideExample
{
    private readonly ILogger<LoggingGuideExample> _logger;
    
    public void DemonstrateLogLevels()
    {
        // ✅ Trace: 코드 흐름 추적 (매우 빈번, 개발 전용)
        _logger.LogTrace("메서드 시작");
        _logger.LogTrace("루프 반복 {Iteration}회차", 5);
        
        // ✅ Debug: 디버깅에 유용한 정보
        int calculatedValue = 42;
        _logger.LogDebug("계산 결과: {Value}", calculatedValue);
        
        // ✅ Information: 애플리케이션의 정상 흐름
        _logger.LogInformation("사용자 로그인 성공");
        _logger.LogInformation("주문 생성 완료 - OrderId: {OrderId}", 12345);
        
        // ✅ Warning: 문제는 아니지만 주의 필요
        _logger.LogWarning("API 응답 시간이 느립니다: {ElapsedMs}ms", 3000);
        _logger.LogWarning("디스크 사용량 80% 초과");
        
        // ✅ Error: 기능 실패, 예외 발생
        try
        {
            // 오류가 발생할 수 있는 코드
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "파일 처리 실패 - FileName: {FileName}", "data.csv");
        }
        
        // ✅ Critical: 시스템 전체에 영향을 미치는 치명적 오류
        _logger.LogCritical("데이터베이스 연결 불가 - 서비스 중단");
    }
}
```

**appsettings.json을 통한 로그 레벨 설정 (ASP.NET Core):**

```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft": "Warning",
      "Microsoft.Hosting.Lifetime": "Information",
      "MyApp": "Debug"
    }
  }
}
```

**실전 활용 팁:**

1. **개발 환경**: Debug 또는 Trace 레벨로 상세한 정보 확인
2. **프로덕션 환경**: Information 이상으로 설정하여 성능 영향 최소화
3. **오류 추적**: Error와 Critical은 항상 기록하고 알림 설정
4. **성능 모니터링**: Warning으로 성능 저하 조기 감지
5. **로그 볼륨 관리**: Trace와 Debug는 프로덕션에서 비활성화

---

## 25장 정리 및 요약

이 장에서는 현대 소프트웨어 개발의 필수 실천 방법인 디버깅과 로깅의 이론적 기반부터 실무 적용까지 포괄적으로 학습했습니다. Grace Hopper의 역사적 사건(1947)에서 시작된 디버깅의 진화, UNIX syslog(1980)에서 구조화된 로깅(2010년대)으로의 발전, 그리고 관측성(Observability)이라는 현대 소프트웨어 공학의 핵심 개념을 깊이 있게 탐구했습니다.

### 핵심 개념의 재조명

**1. 디버깅의 역사적 진화와 경제적 가치:**

1947년 Grace Hopper 대령이 Mark II 컴퓨터에서 실제 나방을 발견한 사건은 단순한 일화를 넘어, 소프트웨어 오류를 체계적으로 다루기 시작한 컴퓨터 과학의 상징적 시작점이 되었습니다. 그 후 70여 년간 디버깅 기술은 다음과 같이 진화했습니다:

- **1960년대**: John McCarthy의 LISP 시스템에 최초의 대화형 디버거
- **1970년대**: UNIX dbx와 GNU gdb의 등장
- **1990년대**: Visual Studio GUI 디버거의 대중화
- **2010년대**: Debug Adapter Protocol (DAP)로 언어 독립적 디버깅 표준 확립
- **현재**: AI 기반 자동 디버깅 도구의 부상

NIST 연구에 따르면 소프트웨어 버그는 미국 경제에 연간 **595억 달러**의 손실을 초래하며, Cambridge University 연구는 개발자가 전체 시간의 **50-75%**를 디버깅과 테스팅에 할애한다고 보고했습니다. 효과적인 디버깅 도구는 문제 해결 시간을 **40-60%** 단축시키는 것으로 확인되었습니다.

**2. Debug Adapter Protocol과 디버거 아키텍처:**

Microsoft가 2018년 표준화한 DAP는 디버거 UI와 디버그 엔진을 분리하여, VS Code가 단일 인터페이스로 C#, Python, JavaScript 등 다양한 언어를 디버깅할 수 있게 만들었습니다. 계층적 아키텍처:

```
VS Code UI ↔ Debug Adapter (DAP) ↔ Runtime Debugger ↔ Target Process
```

각 계층의 역할과 상호작용을 이해하면, 디버깅 문제를 더 효과적으로 해결할 수 있습니다.

**3. 중단점의 작동 원리와 유형:**

중단점은 단순해 보이지만, 그 구현은 정교합니다:

- **소프트웨어 중단점**: 디버거가 명령어를 인터럽트 명령으로 교체. 무제한 개수 가능하지만 약간의 성능 오버헤드.
- **하드웨어 중단점**: CPU 디버그 레지스터 사용. 4개로 제한되지만 코드 수정 없이 작동하며 데이터 중단점 구현 가능.

조건부 중단점, 적중 횟수, 로그 포인트 등 고급 기능을 적절히 활용하면 디버깅 효율성이 크게 향상됩니다.

**4. 심볼 파일(PDB)과 디버깅 정보:**

PDB(Program Database) 파일은 컴파일된 바이너리와 소스 코드를 연결하는 핵심 메타데이터입니다:

- **소스 매핑**: IL 명령어와 소스 줄 번호의 대응
- **변수 정보**: 로컬 변수와 매개변수 이름 보존
- **타입 메타데이터**: 클래스, 구조체, 열거형 정의

.NET Core의 Portable PDB는 크로스 플랫폼 디버깅을 가능하게 하며, Embedded PDB 옵션은 심볼 정보를 DLL에 직접 포함시켜 배포를 간소화합니다.

**5. 로깅의 역사적 발전과 구조화된 로깅:**

로깅은 항해 일지(ship's log)에서 유래한 개념으로, 컴퓨터 과학에서는 다음과 같이 진화했습니다:

- **1980년**: UNIX syslog 표준화로 시스템 로깅 체계 확립
- **1996년**: Log4j 등장으로 애플리케이션 로깅 프레임워크 시대 개막
- **2010년대**: JSON 기반 구조화된 로깅으로 검색과 분석 용이성 획기적 향상
- **2020년대**: OpenTelemetry로 로그, 메트릭, 트레이스 통합

**구조화된 로깅의 혁명:**

전통적 텍스트 로그: `"User Alice logged in from 192.168.1.100"`

구조화된 로그:
```json
{
  "timestamp": "2024-11-15T10:30:15Z",
  "level": "INFO",
  "event": "user_login",
  "user": "Alice",
  "ip_address": "192.168.1.100"
}
```

장점:
- **쿼리 가능**: `user="Alice" AND event="user_login"` 검색
- **집계 용이**: "지난 1시간 로그인 수" 같은 통계 계산
- **타입 안전**: 필드 타입 보존으로 정확한 분석

**6. Microsoft.Extensions.Logging 아키텍처:**

.NET의 표준 로깅 추상화는 Provider 패턴을 사용하여 프레임워크에 독립적인 코드 작성을 가능하게 합니다:

```
ILogger (추상화) → Logging Provider (구현) → 출력 대상 (콘솔, 파일, 클라우드)
```

이 설계는 의존성 역전 원칙(DIP)을 실현하며, 로깅 구현을 교체해도 애플리케이션 코드는 변경할 필요가 없습니다.

**7. 로그 레벨의 의미론과 실무 적용:**

6가지 로그 레벨의 정확한 이해와 적용은 효과적인 로깅의 핵심입니다:

| 레벨 | 개발 환경 | 프로덕션 | 빈도 | 알림 |
|------|----------|---------|------|------|
| **Trace** | ✅ 상세 추적 | ❌ 비활성화 | 초당 수백 건 | 없음 |
| **Debug** | ✅ 디버깅 정보 | ❌ 비활성화 | 초당 수십 건 | 없음 |
| **Information** | ✅ 정상 흐름 | ✅ 기본 레벨 | 분당 수건 | 없음 |
| **Warning** | ✅ 잠재적 문제 | ✅ 모니터링 | 시간당 수건 | 검토 필요 |
| **Error** | ✅ 기능 실패 | ✅ 필수 기록 | 일일 수건 | 즉시 알림 |
| **Critical** | ✅ 시스템 장애 | ✅ 필수 기록 | 드물게 | 긴급 알림 |

**8. 관측성(Observability)의 세 기둥:**

현대 소프트웨어 시스템은 로깅만으로는 충분하지 않습니다. 완전한 관측성을 위해서는 세 요소가 필요합니다:

1. **로그(Logs)**: 이산적 이벤트 기록 - "무슨 일이 일어났는가?"
2. **메트릭(Metrics)**: 시계열 수치 데이터 - "시스템 상태가 어떤가?"
3. **트레이스(Traces)**: 분산 시스템의 요청 흐름 - "어떤 경로로 실행되었는가?"

이 장은 주로 로그와 디버깅에 초점을 맞췄지만, 실무에서는 세 요소를 통합하여 시스템의 전체적인 상태를 이해해야 합니다.

### 실무 디버깅과 로깅 전략

**개발 환경에서의 디버깅 워크플로우:**

1. **문제 재현**: 버그를 일관되게 재현할 수 있는 최소 단계 파악
2. **가설 수립**: 문제의 원인에 대한 가설 형성
3. **전략적 중단점**: 가설을 검증할 수 있는 위치에 중단점 설정
4. **변수 검사**: 예상값과 실제값 비교
5. **단계 실행**: Step Into/Over로 실행 흐름 추적
6. **수정과 검증**: 코드 수정 후 테스트로 검증

**프로덕션 환경에서의 로깅 전략:**

1. **로그 레벨 정책**: Information 이상만 기록하여 볼륨과 비용 관리
2. **구조화된 속성**: 검색 가능한 키-값 쌍으로 기록
3. **컨텍스트 전파**: RequestId, UserId 등으로 관련 로그 연결
4. **민감 정보 마스킹**: 비밀번호, 신용카드 번호 등 제거
5. **로그 샘플링**: 고빈도 이벤트는 샘플링으로 볼륨 감소
6. **로테이션과 보관**: 디스크 공간 관리와 규정 준수

**성능 고려사항:**

- **디버그 모드 오버헤드**: 릴리스 모드 대비 2-10배 느림
- **조건부 중단점 비용**: 조건 평가에 밀리초 소요
- **로그 출력 비용**: 동기 파일 I/O는 수십 밀리초, 비동기 큐 사용 권장
- **구조화된 로깅**: 템플릿 파싱 오버헤드는 미미 (마이크로초), 이점이 훨씬 큼

### 실습 체크리스트

이 장의 학습 내용을 확인하기 위한 실습 과제:

**초급: 디버깅 기초**
- [ ] 중단점 설정하고 F5로 디버그 모드 실행
- [ ] F10 (Step Over)과 F11 (Step Into)의 차이 실습
- [ ] 변수 창에서 컬렉션 내용 탐색
- [ ] 디버그 콘솔에서 LINQ 표현식 실행
- [ ] 조건부 중단점으로 특정 값에서만 중단

**초급: 로깅 기초**
- [ ] Console.WriteLine 대신 ILogger 사용
- [ ] 구조화된 로깅으로 변수를 템플릿으로 전달
- [ ] 6가지 로그 레벨 모두 사용해보기
- [ ] appsettings.json으로 로그 레벨 구성

**중급: 고급 디버깅**
- [ ] 적중 횟수 중단점으로 N번째 반복에서 중단
- [ ] 로그 포인트로 실행 흐름 추적 (중단 없이)
- [ ] 호출 스택에서 이전 프레임으로 이동하며 상태 추적
- [ ] 예외 설정에서 "모든 예외" 활성화하고 숨겨진 예외 찾기

**중급: 고급 로깅**
- [ ] BeginScope로 컨텍스트 정보 자동 추가
- [ ] 여러 로깅 프로바이더 동시 사용 (콘솔 + 파일)
- [ ] 환경별 로그 레벨 동적 설정
- [ ] 특정 네임스페이스만 필터링

**고급: 프로덕션 수준**
- [ ] Serilog 통합하고 Elasticsearch로 로그 전송
- [ ] 분산 추적 구현 (RequestId 전파)
- [ ] 로그 기반 알림 시스템 구축
- [ ] 메모리 덤프 분석으로 프로덕션 이슈 디버깅
- [ ] 성능 프로파일링으로 병목 지점 식별

### 도구와 리소스

**디버깅 도구:**
- **VS Code Debugger**: 크로스 플랫폼, DAP 기반
- **Visual Studio Debugger**: Windows, 최고 수준의 기능
- **dotnet-dump**: 프로덕션 메모리 덤프 캡처 및 분석
- **dotnet-trace**: 성능 추적
- **PerfView**: Windows 성능 분석

**로깅 프레임워크:**
- **Microsoft.Extensions.Logging**: .NET 표준 추상화
- **Serilog**: 구조화된 로깅의 선구자, 풍부한 Sink 생태계
- **NLog**: 유연한 설정, 레거시 지원 우수
- **Log4net**: Apache Log4j 포팅, 성숙한 프레임워크

**로그 집계와 분석:**
- **ELK Stack**: Elasticsearch, Logstash, Kibana
- **Splunk**: 엔터프라이즈급 로그 관리
- **Seq**: .NET에 최적화된 구조화된 로그 서버
- **Application Insights**: Azure 통합 관측성 플랫폼

**권장 도서:**
- **"Debugging: The 9 Indispensable Rules for Finding Even the Most Elusive Software and Hardware Problems"** by David J. Agans
- **"The Art of Monitoring"** by James Turnbull
- **"Distributed Systems Observability"** by Cindy Sridharan (O'Reilly)
- **"Logging in Action"** by Phil Wilkins (Manning)

### 다음 단계와 심화 학습

**고급 디버깅 주제:**
- **메모리 프로파일링**: 메모리 누수 탐지와 힙 분석
- **성능 프로파일링**: CPU 사용, 핫 패스 식별
- **원격 디버깅**: 프로덕션 서버나 컨테이너 디버깅
- **타임 트래블 디버깅**: 과거 상태로 되돌아가는 리버스 디버깅
- **동시성 디버깅**: 스레드, 태스크, 데드락 분석

**고급 로깅 주제:**
- **분산 추적**: OpenTelemetry, Jaeger, Zipkin
- **로그 기반 메트릭**: 로그에서 시계열 데이터 추출
- **로그 상관관계**: 여러 서비스의 로그를 단일 트랜잭션으로 연결
- **로그 보안**: 암호화, 접근 제어, 감사 로그
- **로그 비용 최적화**: 샘플링, 압축, 티어링 전략

**DevOps와 관측성:**
- **Site Reliability Engineering (SRE)**: Google의 SLI, SLO, SLA 개념
- **Chaos Engineering**: 장애 주입으로 시스템 회복력 테스트
- **AIOps**: AI/ML 기반 로그 분석과 이상 감지
- **eBPF 기반 관측성**: 커널 레벨 관측 (Cilium, Pixie)

### 마무리

디버깅과 로깅은 소프트웨어의 "블랙박스"를 투명하게 만드는 관측성(Observability)의 핵심 요소입니다. 이 장에서 학습한 내용:

✅ **역사적 이해**: Grace Hopper (1947) → Debug Adapter Protocol (2018)
✅ **아키텍처 지식**: DAP, PDB, JIT 컴파일과 디버깅의 상호작용
✅ **실무 기술**: 중단점 전략, 변수 검사, 조건부 디버깅
✅ **로깅 철학**: 구조화된 로깅, 로그 레벨, 관측성의 세 기둥
✅ **프레임워크 활용**: Microsoft.Extensions.Logging, Serilog
✅ **운영 전략**: 환경별 설정, 성능 최적화, 비용 관리

다음 장에서는 C# 10의 주요 기능과 모던 C# 프로그래밍 기법을 학습하여, 더 간결하고 표현력 있는 코드를 작성하는 방법을 탐구합니다. 디버깅과 로깅은 26장 이후의 모든 실습에서도 필수적으로 사용될 기본 기술입니다!

**"로그가 없으면 문제가 없었던 것이 아니라, 문제를 볼 수 없었던 것이다."** - Werner Vogels, Amazon CTO
