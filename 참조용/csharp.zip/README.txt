게임 개발 개념 라이브러리 — C# 언어 (C# Language)
========================================

각 HTML 파일은 다른 파일이나 인터넷 연결 없이 브라우저에서 바로 열리는 인터랙티브 슬라이드입니다.
Each HTML file is a self-contained interactive slide deck that opens offline in any modern browser.

- csharp--functions.html  —  함수와 메서드 (Functions & Methods)
- csharp--oop.html  —  객체지향 프로그래밍 (Object-Oriented Programming)
- csharp--solid-principles.html  —  객체지향 설계 원칙 (OOP Design Principles (SOLID))
- csharp--syntax-basics.html  —  C# 문법 기초 (C# Syntax Basics)
- csharp--value-vs-reference.html  —  복사와 참조: 스택과 힙 (Value vs Reference Types (Stack & Heap))
