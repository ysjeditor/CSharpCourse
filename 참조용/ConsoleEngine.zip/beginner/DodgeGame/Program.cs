new DodgeGame().Run();
