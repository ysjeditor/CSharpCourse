# 3장. 제어문

2장에서 변수, 연산자, 입출력을 배웠습니다. 하지만 지금까지 작성한 프로그램은 위에서 아래로 순차적으로만 실행되었습니다. 실제 프로그램에서는 상황에 따라 다른 코드를 실행하거나, 같은 코드를 반복해야 하는 경우가 많습니다. 이러한 프로그램 흐름의 제어를 가능하게 하는 것이 바로 **제어문(Control Flow Statements)**입니다.

제어문은 크게 세 가지로 나뉩니다:
- **조건문**: 조건에 따라 다른 코드 실행 (`if`, `switch`)
- **반복문**: 코드를 여러 번 반복 실행 (`for`, `while`, `foreach`)
- **분기문**: 반복이나 함수의 흐름 변경 (`break`, `continue`, `return`)

## 이 장에서 배울 내용

- `if`, `else if`, `else` 문을 사용한 조건 분기
- `switch` 문과 패턴 매칭
- `for`, `while`, `do-while`, `foreach` 반복문
- `break`, `continue`, `return` 분기문

---

## 3.1 조건문

조건문은 프로그램이 상황에 따라 다르게 동작하도록 만드는 핵심 메커니즘입니다. 일상생활에서 "만약 비가 오면 우산을 가져간다"와 같은 조건부 행동을 하듯이, 프로그램도 조건문을 통해 "만약 사용자 입력이 유효하면 처리를 진행한다"와 같은 논리를 구현할 수 있습니다. C#은 전통적인 `if` 문부터 현대적인 패턴 매칭과 switch 식에 이르기까지 다양한 조건문 구문을 제공하여, 개발자가 상황에 맞는 최적의 표현 방법을 선택할 수 있도록 합니다.

### 3.1.1 if 문

`if` 문은 가장 기본적이면서도 가장 많이 사용되는 조건문으로, 컴퓨터 프로그래밍의 의사 결정 메커니즘을 구현하는 핵심 도구입니다. 주어진 조건식이 `true`로 평가될 때만 특정 코드 블록을 실행하는 단순하지만 강력한 구조를 가지고 있으며, 이는 프로그램이 다양한 상황에 대응하여 적절한 행동을 선택할 수 있게 해줍니다.

역사적으로 if 문은 1950년대 후반 존 매카시(John McCarthy)가 LISP 언어를 개발하면서 조건부 표현식(conditional expression)의 개념을 도입한 이후로 거의 모든 프로그래밍 언어의 필수 요소가 되었습니다. C#의 if 문은 C 언어 계열의 전통을 계승하면서도, 타입 안정성과 명확성을 더욱 강화한 형태로 발전했습니다.

**기본 구조:**

```csharp
if (조건식)
{
    // 조건이 true일 때 실행될 코드
}
```

조건식은 반드시 `bool` 타입(true 또는 false)으로 평가되어야 합니다. 이는 C#이 타입 안정성(Type Safety)을 중시하는 언어라는 점을 잘 보여주는 특징입니다. C나 JavaScript와 같은 언어에서는 정수 0을 거짓으로, 0이 아닌 값을 참으로 해석하는 암묵적 변환을 허용하지만, C#은 이러한 모호함을 배제하고 명시적인 불린 표현식만을 요구합니다. 이는 의도하지 않은 버그를 사전에 방지하고, 코드의 의도를 명확하게 드러내는 데 도움을 줍니다.

**실전 예제:**

```csharp
int age = 20;

if (age >= 18)
{
    Console.WriteLine("성인입니다.");
}

// 출력: 성인입니다.
```

**단일 문장일 때의 중괄호 생략과 코딩 관례:**

문법적으로 조건이 참일 때 실행할 코드가 단 한 줄이라면 중괄호를 생략할 수 있습니다. 이는 C 언어 계열의 문법적 특성을 그대로 계승한 것입니다. 하지만 소프트웨어 공학적 관점에서 보면, 가독성과 유지보수성을 위해 항상 중괄호를 사용하는 것이 강력히 권장됩니다.

중괄호를 생략했을 때의 주요 위험성은 코드 수정 과정에서 발생합니다. 나중에 조건부로 실행해야 할 코드를 추가할 때, 중괄호가 없으면 두 번째 문장은 if 문의 범위 밖에 있게 되어 의도하지 않은 동작을 유발할 수 있습니다. 실제로 이러한 실수는 Apple의 유명한 "goto fail" 보안 취약점처럼 심각한 버그로 이어진 사례가 있습니다. Microsoft의 C# 코딩 규칙과 대부분의 산업 표준 가이드라인에서도 항상 중괄호를 사용하도록 명시하고 있습니다.

```csharp
int score = 95;

// 중괄호 생략 (권장하지 않음)
if (score >= 90)
    Console.WriteLine("A학점입니다.");

// 중괄호 사용 (권장)
if (score >= 90)
{
    Console.WriteLine("A학점입니다.");
}
```

**복잡한 조건식과 논리 연산자:**

프로그래밍의 실무에서는 단순한 단일 조건보다 여러 조건을 조합한 복잡한 논리식을 더 자주 접하게 됩니다. C#은 불린 대수학(Boolean Algebra)의 원리에 기반한 논리 연산자(`&&`, `||`, `!`)를 제공하여 여러 조건을 조합할 수 있습니다.

**단락 평가(Short-circuit Evaluation)의 이해:**

C#의 논리 연산자는 단락 평가(또는 지연 평가, lazy evaluation)라는 중요한 최적화 기법을 사용합니다. `&&` 연산자의 경우, 왼쪽 피연산자가 거짓이면 오른쪽 피연산자를 평가하지 않습니다. 왜냐하면 AND 연산에서 하나라도 거짓이면 전체 결과가 거짓이기 때문입니다. 마찬가지로 `||` 연산자는 왼쪽 피연산자가 참이면 오른쪽을 평가하지 않습니다.

이러한 단락 평가는 단순한 성능 최적화를 넘어서, 코드의 안전성을 보장하는 중요한 역할을 합니다. 예를 들어, null 검사와 속성 접근을 조합할 때 순서가 중요한데, 단락 평가가 이를 자연스럽게 처리해줍니다.

```csharp
int temperature = 25;
bool isSunny = true;

if (temperature >= 20 && temperature <= 30 && isSunny)
{
    Console.WriteLine("산책하기 좋은 날씨입니다.");
}

// 출력: 산책하기 좋은 날씨입니다.
```

**조건식의 가독성 향상 기법:**

복잡한 조건식은 괄호를 사용하여 명시적으로 우선순위를 표현하거나, 의미 있는 변수명으로 분리하여 가독성을 높일 수 있습니다. 예를 들어, `isWeatherPerfectForWalking` 같은 변수에 복잡한 조건을 저장하면 코드의 의도가 훨씬 명확해집니다.

### 3.1.2 else if와 else

단순히 하나의 조건만 검사하는 것을 넘어서, 실제 프로그래밍 환경에서는 여러 가지 조건을 순차적으로 검사하거나 조건이 거짓일 때의 대안적 실행 경로를 제시해야 하는 경우가 훨씬 더 빈번합니다. 이때 `else if`와 `else` 절을 사용하여 다중 분기(multi-way branching) 로직을 구현할 수 있습니다.

이러한 다중 조건 검사 구조는 결정 트리(decision tree) 또는 의사 결정 플로우차트의 프로그래밍 언어적 표현이라고 볼 수 있습니다. 각 조건은 하나의 결정 노드를 나타내며, 프로그램의 실행 흐름은 조건의 참/거짓 여부에 따라 서로 다른 가지로 분기됩니다.

**else if 구조의 실행 원리:**

`else if` 구조는 여러 조건을 순차적으로 검사하며, 가장 먼저 참이 되는 조건의 블록만 실행한 후 전체 조건문을 빠져나갑니다. 이후의 조건은 검사조차 하지 않습니다. 이는 컴퓨터 과학에서 말하는 "상호 배타적 선택(mutually exclusive choice)"의 개념을 구현한 것으로, 각 분기는 서로 겹치지 않는 독립적인 실행 경로를 나타냅니다.

이러한 순차적 검사와 조기 종료(early exit) 메커니즘은 불필요한 조건 평가를 방지하여 성능을 향상시킬 뿐만 아니라, 논리적 오류를 줄이는 데도 도움을 줍니다.

```csharp
int score = 85;

if (score >= 90)
{
    Console.WriteLine("A학점: 우수합니다!");
}
else if (score >= 80)
{
    Console.WriteLine("B학점: 잘했습니다!");
}
else if (score >= 70)
{
    Console.WriteLine("C학점: 보통입니다.");
}
else if (score >= 60)
{
    Console.WriteLine("D학점: 분발이 필요합니다.");
}
else
{
    Console.WriteLine("F학점: 재수강이 필요합니다.");
}

// 출력: B학점: 잘했습니다!
```

**조건 검사의 순서와 알고리즘적 고려사항:**

조건은 위에서 아래로 순차적으로 검사되며, 첫 번째로 참이 되는 조건의 블록만 실행됩니다. 따라서 조건의 순서는 프로그램의 동작뿐만 아니라 성능에도 큰 영향을 미칩니다. 이는 알고리즘 설계에서 중요한 최적화 기법 중 하나입니다.

**조건 순서의 중요성:**
1. **논리적 정확성**: 더 구체적이고 제한적인 조건을 먼저 배치해야 합니다. 그렇지 않으면 일반적인 조건이 먼저 매칭되어 특수한 경우를 처리할 기회를 잃게 됩니다.
2. **성능 최적화**: 통계적으로 더 자주 발생하는 조건을 앞에 배치하면, 평균적으로 더 적은 조건 검사로 결과에 도달할 수 있습니다.
3. **유지보수성**: 조건이 논리적으로 자연스러운 순서로 배치되어 있으면, 코드를 읽고 이해하기가 훨씬 쉬워집니다.

```csharp
int number = 15;

// 잘못된 순서 예제 - 일반적인 조건이 먼저 나옴
if (number > 0)
{
    Console.WriteLine("양수입니다.");  // 이것이 실행됨
}
else if (number > 10)
{
    Console.WriteLine("10보다 큽니다.");  // 실행되지 않음 (위 조건이 먼저 참이 되므로)
}

// 올바른 순서 예제 - 구체적인 조건이 먼저 나옴
if (number > 10)
{
    Console.WriteLine("10보다 큰 양수입니다.");
}
else if (number > 0)
{
    Console.WriteLine("10 이하의 양수입니다.");
}
```

**중첩된 if 문과 코드 복잡도 관리:**

if 문 안에 또 다른 if 문을 넣어 더 복잡한 조건 로직을 구현할 수 있습니다. 이를 중첩 조건문(nested conditionals)이라고 하며, 다차원적인 의사 결정 과정을 표현할 수 있게 해줍니다. 그러나 소프트웨어 공학의 관점에서 볼 때, 과도한 중첩은 코드의 순환 복잡도(cyclomatic complexity)를 높여 이해와 유지보수를 어렵게 만듭니다.

```csharp
int age = 25;
bool hasLicense = true;

if (age >= 18)
{
    if (hasLicense)
    {
        Console.WriteLine("운전할 수 있습니다.");
    }
    else
    {
        Console.WriteLine("면허증이 필요합니다.");
    }
}
else
{
    Console.WriteLine("성인이 아닙니다.");
}

// 출력: 운전할 수 있습니다.
```

**중첩 제거와 코드 평탄화(Flattening):**

중첩된 if 문은 가독성을 해칠 수 있으므로, 가능하면 논리 연산자를 사용하여 단순화하는 것이 좋습니다. 이는 "조기 반환(early return)" 패턴이나 "보호 절(guard clauses)" 같은 리팩토링 기법과도 연결됩니다. 코드를 평탄하게 만들면 각 조건의 의도가 더 명확해지고, 테스트와 디버깅도 쉬워집니다.

```csharp
// 위 코드를 논리 연산자로 단순화
if (age >= 18 && hasLicense)
{
    Console.WriteLine("운전할 수 있습니다.");
}
else if (age >= 18 && !hasLicense)
{
    Console.WriteLine("면허증이 필요합니다.");
}
else
{
    Console.WriteLine("성인이 아닙니다.");
}
```

이렇게 단순화된 코드는 각 조건이 독립적으로 명확하게 표현되어, 코드 리뷰나 유지보수 시에 훨씬 이해하기 쉽습니다.

### 3.1.3 switch 문과 패턴 매칭

`switch` 문은 하나의 값을 여러 경우(case)와 비교하여 일치하는 경우의 코드를 실행하는 조건문으로, 다중 if-else 문의 보다 구조화되고 효율적인 대안을 제공합니다. 여러 개의 `else if`를 나열하는 것보다 더 명확하고 읽기 쉬운 코드를 작성할 수 있으며, 컴파일러 최적화의 관점에서도 이점이 있습니다.

**switch 문의 역사와 발전:**

switch 문은 1970년대 C 언어에서 처음 도입되었으며, 원래는 단순한 정수 값 비교만을 지원했습니다. 그러나 C#은 이를 크게 확장하여 문자열, 열거형(enum), 그리고 더 나아가 C# 7.0부터는 강력한 패턴 매칭 기능까지 도입했습니다. 이는 함수형 프로그래밍 언어들(F#, Haskell, Scala 등)의 패턴 매칭 개념을 C#에 접목시킨 것으로, 표현력과 안전성을 크게 향상시켰습니다.

**컴파일러 최적화의 이점:**

switch 문은 컴파일러가 점프 테이블(jump table) 또는 이진 탐색 트리(binary search tree) 같은 최적화 기법을 적용할 수 있어, 많은 경우의 수를 다룰 때 연속된 if-else 문보다 더 효율적입니다. 특히 case 값들이 연속적이거나 밀집되어 있을 때 점프 테이블을 통해 O(1) 시간 복잡도로 해당 case로 직접 이동할 수 있습니다.

**기본 switch 문:**

```csharp
int dayOfWeek = 3;

switch (dayOfWeek)
{
    case 1:
        Console.WriteLine("월요일");
        break;
    case 2:
        Console.WriteLine("화요일");
        break;
    case 3:
        Console.WriteLine("수요일");
        break;
    case 4:
        Console.WriteLine("목요일");
        break;
    case 5:
        Console.WriteLine("금요일");
        break;
    case 6:
        Console.WriteLine("토요일");
        break;
    case 7:
        Console.WriteLine("일요일");
        break;
    default:
        Console.WriteLine("잘못된 요일 번호입니다.");
        break;
}

// 출력: 수요일
```

**중요한 특징과 C#의 안전성 설계:**

1. **break 문의 필수성과 의도적 설계**: 각 case 블록의 끝에는 반드시 `break` 문이 있어야 합니다. 이는 다음 case로 넘어가는 것(fall-through)을 방지합니다. C/C++에서는 break를 생략하면 다음 case로 자동으로 진행되는데, 이는 종종 버그의 원인이 되었습니다. C#은 이러한 문제를 원천적으로 차단하기 위해 break를 강제합니다. 이는 C#이 개발자의 실수를 방지하고 코드의 의도를 명확히 하려는 설계 철학을 잘 보여줍니다.

2. **default 절의 역할**: 모든 case에 일치하지 않을 때 실행되는 블록입니다. 필수는 아니지만, 방어적 프로그래밍(defensive programming)의 관점에서 예상치 못한 값을 처리하기 위해 사용하는 것이 좋습니다. 특히 외부 입력을 처리하거나 열거형을 사용할 때, default 절은 예외적인 상황을 안전하게 처리하는 안전망 역할을 합니다.

**여러 case를 묶어서 처리:**

여러 값에 대해 같은 동작을 수행하려면 case를 연속해서 나열할 수 있습니다.

```csharp
int month = 12;

switch (month)
{
    case 12:
    case 1:
    case 2:
        Console.WriteLine("겨울");
        break;
    case 3:
    case 4:
    case 5:
        Console.WriteLine("봄");
        break;
    case 6:
    case 7:
    case 8:
        Console.WriteLine("여름");
        break;
    case 9:
    case 10:
    case 11:
        Console.WriteLine("가을");
        break;
    default:
        Console.WriteLine("잘못된 월입니다.");
        break;
}

// 출력: 겨울
```

**타입 패턴 매칭의 혁신:**

C# 7.0부터는 switch 문에서 타입 패턴을 사용할 수 있어, 객체지향 프로그래밍의 다형성(polymorphism)을 더욱 우아하게 처리할 수 있게 되었습니다. 이는 전통적인 `is` 연산자와 타입 캐스팅을 조합하는 방식보다 훨씬 간결하고 안전합니다.

타입 패턴 매칭은 특히 다양한 타입을 처리해야 하는 파서(parser), 직렬화/역직렬화 로직, 또는 방문자 패턴(Visitor Pattern) 구현 시 매우 유용합니다. 컴파일러가 타입 안정성을 보장하면서도, 코드는 함수형 프로그래밍의 패턴 매칭처럼 선언적이고 표현력이 풍부해집니다.

```csharp
object value = "Hello";

switch (value)
{
    case int i:
        Console.WriteLine($"정수: {i}");
        break;
    case string s:
        Console.WriteLine($"문자열: {s}");
        break;
    case bool b:
        Console.WriteLine($"불린: {b}");
        break;
    case null:
        Console.WriteLine("null 값");
        break;
    default:
        Console.WriteLine("알 수 없는 타입");
        break;
}

// 출력: 문자열: Hello
```

**when 절을 사용한 조건 가드(Condition Guards):**

패턴 매칭과 함께 `when` 절을 사용하면 추가 조건을 지정할 수 있습니다. 이를 조건 가드(condition guards) 또는 가드 절(guard clauses)이라고 부르며, 함수형 프로그래밍 언어의 패턴 가드 개념을 도입한 것입니다.

when 절은 패턴 매칭의 표현력을 크게 확장시켜, 타입 검사와 값 검사를 한 곳에서 우아하게 처리할 수 있게 합니다. 이는 복잡한 비즈니스 로직을 선언적이고 읽기 쉬운 형태로 표현하는 데 매우 효과적입니다.

```csharp
int number = 15;

switch (number)
{
    case int n when n < 0:
        Console.WriteLine("음수입니다.");
        break;
    case int n when n == 0:
        Console.WriteLine("0입니다.");
        break;
    case int n when n > 0 && n <= 10:
        Console.WriteLine("1부터 10 사이의 양수입니다.");
        break;
    case int n when n > 10:
        Console.WriteLine("10보다 큰 양수입니다.");
        break;
}

// 출력: 10보다 큰 양수입니다.
```

이러한 when 절의 활용은 전통적인 if-else 체인보다 의도가 명확하며, 각 경우가 시각적으로 구분되어 코드의 구조를 파악하기 쉽습니다.

### 3.1.4 switch 식 (Switch Expression)

C# 8.0에서 도입된 **switch 식(Switch Expression)**은 전통적인 switch 문을 더욱 간결하고 함수형 프로그래밍 스타일로 표현할 수 있게 해주는 혁신적인 기능입니다. 이는 단순한 문법적 간소화를 넘어서, 프로그래밍 패러다임의 변화를 반영한 것입니다.

**문(Statement)과 식(Expression)의 근본적 차이:**

전통적인 switch는 문(statement)으로서, 어떤 동작을 수행하지만 값을 반환하지 않습니다. 반면 switch 식은 표현식(expression)으로서, 평가되어 값을 생성합니다. 이는 함수형 프로그래밍의 핵심 개념 중 하나인 "모든 것은 값이다(Everything is a value)"라는 철학을 반영합니다.

식으로서의 switch는 다음과 같은 이점을 제공합니다:
- **불변성(Immutability) 지향**: 변수에 값을 할당하는 과정이 선언과 동시에 이루어져, 변수의 생명주기 동안 불변성을 유지하기 쉽습니다.
- **간결성**: 중복되는 반복 코드(변수 선언, break 문 등)를 제거하여 의도가 더 명확해집니다.
- **완전성 검사(Exhaustiveness Checking)**: 컴파일러가 모든 가능한 경우를 다루었는지 검사할 수 있어, 런타임 오류를 사전에 방지합니다.
- **조합 가능성**: 다른 표현식과 자유롭게 조합하여 더 복잡한 로직을 구성할 수 있습니다.

**기본 구조:**

```csharp
var result = value switch
{
    pattern1 => expression1,
    pattern2 => expression2,
    _ => defaultExpression
};
```

여기서 `_`는 모든 경우에 일치하는 discard 패턴으로, switch 문의 `default`와 같은 역할을 합니다.

**실전 예제:**

```csharp
// 전통적인 switch 문
int dayOfWeek = 3;
string dayName;

switch (dayOfWeek)
{
    case 1:
        dayName = "월요일";
        break;
    case 2:
        dayName = "화요일";
        break;
    case 3:
        dayName = "수요일";
        break;
    case 4:
        dayName = "목요일";
        break;
    case 5:
        dayName = "금요일";
        break;
    case 6:
        dayName = "토요일";
        break;
    case 7:
        dayName = "일요일";
        break;
    default:
        dayName = "알 수 없음";
        break;
}

// switch 식으로 간결하게 표현
string dayName2 = dayOfWeek switch
{
    1 => "월요일",
    2 => "화요일",
    3 => "수요일",
    4 => "목요일",
    5 => "금요일",
    6 => "토요일",
    7 => "일요일",
    _ => "알 수 없음"
};

Console.WriteLine(dayName2);
// 출력: 수요일
```

**관계 패턴과 논리 패턴:**

C# 9.0에서는 switch 식에서 관계 패턴(`<`, `>`, `<=`, `>=`)과 논리 패턴(`and`, `or`, `not`)을 사용할 수 있어 더욱 표현력이 풍부해졌습니다.

```csharp
int score = 85;

string grade = score switch
{
    >= 90 => "A학점",
    >= 80 and < 90 => "B학점",
    >= 70 and < 80 => "C학점",
    >= 60 and < 70 => "D학점",
    < 60 => "F학점",
    _ => "잘못된 점수"
};

Console.WriteLine(grade);
// 출력: B학점
```

**튜플 패턴:**

여러 값을 동시에 평가하는 튜플 패턴도 사용할 수 있습니다.

```csharp
string GetQuadrant(int x, int y) => (x, y) switch
{
    (0, 0) => "원점",
    (> 0, > 0) => "1사분면",
    (< 0, > 0) => "2사분면",
    (< 0, < 0) => "3사분면",
    (> 0, < 0) => "4사분면",
    (0, _) => "X축 위",
    (_, 0) => "Y축 위"
};

Console.WriteLine(GetQuadrant(3, 4));   // 출력: 1사분면
Console.WriteLine(GetQuadrant(-2, 5));  // 출력: 2사분면
Console.WriteLine(GetQuadrant(0, 0));   // 출력: 원점
```

**속성 패턴:**

객체의 속성값을 기반으로 패턴 매칭을 수행할 수도 있습니다.

```csharp
public class Person
{
    public string Name { get; set; }
    public int Age { get; set; }
}

Person person = new Person { Name = "김철수", Age = 25 };

string description = person switch
{
    { Age: < 18 } => "미성년자",
    { Age: >= 18 and < 65 } => "성인",
    { Age: >= 65 } => "노인",
    _ => "알 수 없음"
};

Console.WriteLine(description);
// 출력: 성인
```

switch 식의 주요 장점은 더 간결한 코드, 표현식으로서의 값 반환, 그리고 컴파일러의 완전성 검사(모든 가능한 경우를 다루었는지 확인)입니다.

---

## 3.2 반복문

프로그래밍에서 반복은 피할 수 없는 작업입니다. 동일하거나 유사한 작업을 여러 번 수행해야 하는 경우, 코드를 복사-붙여넣기 하는 대신 **반복문(Loop Statements)**을 사용하여 효율적으로 처리할 수 있습니다. C#은 다양한 상황에 맞는 네 가지 주요 반복문을 제공합니다: `for`, `while`, `do-while`, `foreach`. 각 반복문은 특정 사용 사례에 최적화되어 있으므로, 상황에 맞는 적절한 반복문을 선택하는 것이 중요합니다.

### 3.2.1 for 문

`for` 문은 반복 횟수를 명확히 알고 있을 때 사용하는 가장 일반적이고 강력한 반복문입니다. 초기화, 조건 검사, 증감식이 한 줄에 명시되어 있어 반복의 구조를 한눈에 파악할 수 있다는 장점이 있으며, 이는 코드의 가독성과 유지보수성을 크게 향상시킵니다.

**for 문의 역사적 배경과 설계 철학:**

for 문은 1958년 ALGOL 58 언어에서 처음 도입된 이후, 거의 모든 절차적 프로그래밍 언어의 표준 구성 요소가 되었습니다. C 언어에서 확립된 현재의 3부분 구조(초기화; 조건; 증감)는 매우 효율적이고 표현력이 뛰어나, 오늘날까지도 변함없이 사용되고 있습니다. C#의 for 문은 이러한 전통을 계승하면서도, 타입 안정성과 범위 지정을 통해 더욱 안전하게 진화했습니다.

**기본 구조:**

```csharp
for (초기화; 조건식; 증감식)
{
    // 반복 실행될 코드
}
```

**실행 메커니즘의 상세한 이해:**

for 문의 실행 과정을 정확히 이해하는 것은 복잡한 반복 로직을 구현할 때 매우 중요합니다:

1. **초기화 (Initialization)**: 반복문이 시작될 때 단 한 번만 실행됩니다. 여기서 선언된 변수는 for 문의 범위(scope) 내에서만 유효하며, 이는 변수의 생명주기를 명확히 하여 버그를 방지합니다.
2. **조건식 검사 (Condition Check)**: 각 반복이 시작되기 전에 평가됩니다. 조건이 true이면 반복 블록을 실행하고, false이면 for 문을 빠져나갑니다. 중요한 점은 반복 블록이 한 번도 실행되지 않을 수도 있다는 것입니다 (조건이 처음부터 거짓인 경우).
3. **반복 블록 실행 (Loop Body)**: 조건이 참일 때 수행될 실제 작업입니다.
4. **증감식 실행 (Increment/Decrement)**: 반복 블록이 실행된 후에 수행됩니다. 보통 반복 변수의 값을 변경하여 종료 조건에 가까워지도록 합니다.
5. **순환 (Iteration)**: 2단계로 돌아가서 조건을 다시 검사합니다.

**기본 예제:**

```csharp
// 1부터 5까지 출력
for (int i = 1; i <= 5; i++)
{
    Console.WriteLine(i);
}

// 출력:
// 1
// 2
// 3
// 4
// 5
```

**역순 반복:**

```csharp
// 10부터 1까지 카운트다운
for (int i = 10; i >= 1; i--)
{
    Console.WriteLine(i);
}
Console.WriteLine("발사!");

// 출력:
// 10
// 9
// ...
// 1
// 발사!
```

**증가값 조절:**

```csharp
// 짝수만 출력 (0부터 10까지)
for (int i = 0; i <= 10; i += 2)
{
    Console.WriteLine(i);
}

// 출력:
// 0
// 2
// 4
// 6
// 8
// 10
```

**중첩된 for 문:**

반복문 안에 또 다른 반복문을 넣어 다차원적인 반복을 구현할 수 있습니다. 구구단이나 행렬 처리 등에 유용합니다.

```csharp
// 구구단 2단부터 9단까지 출력
for (int dan = 2; dan <= 9; dan++)
{
    Console.WriteLine($"\n=== {dan}단 ===");
    for (int num = 1; num <= 9; num++)
    {
        Console.WriteLine($"{dan} × {num} = {dan * num}");
    }
}
```

**배열 순회:**

```csharp
int[] numbers = { 10, 20, 30, 40, 50 };

for (int i = 0; i < numbers.Length; i++)
{
    Console.WriteLine($"인덱스 {i}: {numbers[i]}");
}

// 출력:
// 인덱스 0: 10
// 인덱스 1: 20
// 인덱스 2: 30
// 인덱스 3: 40
// 인덱스 4: 50
```

**여러 변수 사용:**

```csharp
// 초기화와 증감식에 여러 변수 사용 가능
for (int i = 0, j = 10; i < 5; i++, j--)
{
    Console.WriteLine($"i = {i}, j = {j}");
}

// 출력:
// i = 0, j = 10
// i = 1, j = 9
// i = 2, j = 8
// i = 3, j = 7
// i = 4, j = 6
```

### 3.2.2 while 문

`while` 문은 조건이 참인 동안 코드 블록을 반복 실행하는 반복문으로, 반복 횟수를 미리 알 수 없거나 특정 조건이 충족될 때까지 반복해야 하는 상황에 최적화되어 있습니다. `for` 문보다 구조가 단순하여 조건 중심의 반복 로직을 더 명확하게 표현할 수 있습니다.

**while 문의 특성과 적용 시나리오:**

while 문은 "~하는 동안(while)" 이라는 자연어 표현과 직접적으로 대응되어, 조건이 만족되는 한 계속 실행되어야 하는 로직을 표현하기에 매우 직관적입니다. 특히 다음과 같은 상황에서 while 문이 선호됩니다:

- **이벤트 대기 (Event Waiting)**: 특정 이벤트나 조건이 발생할 때까지 대기해야 할 때
- **사용자 입력 처리 (User Input Handling)**: 유효한 입력을 받을 때까지 반복할 때
- **파일이나 스트림 처리 (Stream Processing)**: 데이터의 끝에 도달할 때까지 읽어야 할 때
- **게임 루프 (Game Loop)**: 게임이 종료될 때까지 계속 실행되어야 할 때

while 문은 반복 횟수가 데이터나 외부 조건에 의해 동적으로 결정될 때 그 진가를 발휘합니다. 이는 for 문의 정적인 카운팅 방식과 대비되는 특징입니다.

**기본 구조:**

```csharp
while (조건식)
{
    // 조건이 true인 동안 반복 실행될 코드
}
```

**실행 순서:**
1. 조건식 검사
2. 조건이 true이면 반복 블록 실행, false이면 반복문 종료
3. 1단계로 돌아가서 반복

**기본 예제:**

```csharp
int count = 1;

while (count <= 5)
{
    Console.WriteLine(count);
    count++;
}

// 출력:
// 1
// 2
// 3
// 4
// 5
```

**조건 기반 반복:**

사용자 입력을 받아 특정 조건이 만족될 때까지 반복하는 것은 `while` 문의 전형적인 사용 사례입니다.

```csharp
string input = "";

while (input != "종료")
{
    Console.Write("명령을 입력하세요 (종료를 입력하면 프로그램이 종료됩니다): ");
    input = Console.ReadLine();
    
    if (input != "종료")
    {
        Console.WriteLine($"입력한 명령: {input}");
    }
}

Console.WriteLine("프로그램을 종료합니다.");
```

**무한 루프와 그 필요성:**

조건식에 `true`를 직접 사용하면 무한히 반복되는 루프를 만들 수 있습니다. 일견 위험해 보이지만, 무한 루프는 실제 프로그래밍에서 매우 중요한 역할을 합니다. 서버 애플리케이션, 운영체제의 커널, 임베디드 시스템 등은 종료될 때까지 계속 실행되어야 하므로 무한 루프를 기반으로 설계됩니다.

중요한 것은 무한 루프 내부에 적절한 탈출 조건을 `break` 문으로 구현하는 것입니다. 이는 "루프 불변식(loop invariant)"을 유지하면서도 다양한 종료 조건을 유연하게 처리할 수 있게 해줍니다.

```csharp
int attempts = 0;
int maxAttempts = 3;

while (true)
{
    Console.Write("비밀번호를 입력하세요: ");
    string password = Console.ReadLine();
    attempts++;
    
    if (password == "1234")
{
        Console.WriteLine("로그인 성공!");
        break;  // 반복문 탈출
    }
    
    if (attempts >= maxAttempts)
    {
        Console.WriteLine("시도 횟수 초과. 접근이 거부되었습니다.");
        break;
    }
    
    Console.WriteLine($"비밀번호가 틀렸습니다. ({maxAttempts - attempts}번 남음)");
}
```

**while vs for - 선택의 기준과 소프트웨어 공학적 고려:**

일반적으로 반복 횟수가 명확하면 `for` 문을, 조건 중심의 반복이면 `while` 문을 사용하는 것이 관례입니다. 이는 단순한 스타일의 문제가 아니라, 코드의 의도를 명확히 전달하는 중요한 선택입니다.

**선택 가이드라인:**
- **for 문**: 배열 순회, 정해진 횟수만큼 반복, 인덱스가 필요한 경우
- **while 문**: 조건이 충족될 때까지 반복, 이벤트 대기, 스트림 처리

두 반복문은 이론적으로 서로 변환 가능하며(튜링 완전성, Turing Completeness), 실제로 for 문은 while 문의 특수한 형태로 볼 수 있습니다. 그러나 적절한 반복문을 선택하면 코드의 의도가 명확해지고, 미래의 유지보수 담당자(종종 미래의 자신)가 코드를 이해하기 쉬워집니다.

```csharp
// for 문 - 반복 횟수가 명확함
for (int i = 0; i < 5; i++)
{
    Console.WriteLine(i);
}

// 동일한 동작의 while 문 - 덜 자연스러움
int i = 0;
while (i < 5)
{
    Console.WriteLine(i);
    i++;
}
```

### 3.2.3 do-while 문

`do-while` 문은 `while` 문과 유사하지만, 조건 검사를 반복 블록을 실행한 **후에** 수행한다는 중요한 차이점이 있습니다. 이는 반복 블록이 최소 한 번은 반드시 실행되어야 하는 경우에 매우 유용하며, 특정 프로그래밍 패턴에서 필수적입니다.

**사후 검사(Post-condition Check)의 의미:**

do-while 문은 사후 검사(post-condition) 반복문으로 분류됩니다. 이는 사전 검사(pre-condition) 방식인 while, for 문과 대비되는 특성입니다. 사후 검사 방식은 다음과 같은 상황에서 특히 유용합니다:

- **사용자 인터페이스**: 메뉴를 최소 한 번은 보여주어야 하는 경우
- **입력 검증**: 적어도 한 번은 입력을 받아야 하는 경우
- **초기화 후 반복**: 먼저 작업을 수행한 다음 계속 여부를 결정해야 하는 경우

이러한 패턴에서 do-while을 사용하면 별도의 플래그 변수나 반복적인 코드 없이도 로직을 자연스럽게 표현할 수 있습니다.

**기본 구조:**

```csharp
do
{
    // 최소 한 번은 실행되고, 조건이 true인 동안 반복 실행될 코드
} while (조건식);
```

**실행 순서:**
1. 반복 블록 실행 (조건 검사 없이 무조건 실행)
2. 조건식 검사
3. 조건이 true이면 1단계로 돌아가서 반복, false이면 반복문 종료

**기본 예제:**

```csharp
int count = 1;

do
{
    Console.WriteLine(count);
    count++;
} while (count <= 5);

// 출력:
// 1
// 2
// 3
// 4
// 5
```

**while과 do-while의 차이:**

조건이 처음부터 거짓일 때 차이가 명확하게 드러납니다.

```csharp
int x = 10;

// while 문: 조건이 거짓이므로 한 번도 실행되지 않음
while (x < 5)
{
    Console.WriteLine("while: " + x);
}

// do-while 문: 조건이 거짓이어도 한 번은 실행됨
do
{
    Console.WriteLine("do-while: " + x);
} while (x < 5);

// 출력:
// do-while: 10
```

**사용자 입력 검증:**

`do-while` 문은 사용자로부터 유효한 입력을 받을 때까지 반복하는 상황에서 특히 유용합니다.

```csharp
int number;
bool isValid;

do
{
    Console.Write("1부터 10 사이의 숫자를 입력하세요: ");
    string input = Console.ReadLine();
    isValid = int.TryParse(input, out number) && number >= 1 && number <= 10;
    
    if (!isValid)
    {
        Console.WriteLine("잘못된 입력입니다. 다시 시도하세요.");
    }
} while (!isValid);

Console.WriteLine($"입력한 숫자: {number}");
```

**메뉴 시스템:**

```csharp
int choice;

do
{
    Console.WriteLine("\n=== 메뉴 ===");
    Console.WriteLine("1. 새 게임");
    Console.WriteLine("2. 이어하기");
    Console.WriteLine("3. 설정");
    Console.WriteLine("0. 종료");
    Console.Write("선택: ");
    
    int.TryParse(Console.ReadLine(), out choice);
    
    switch (choice)
    {
        case 1:
            Console.WriteLine("새 게임을 시작합니다.");
            break;
        case 2:
            Console.WriteLine("저장된 게임을 불러옵니다.");
            break;
        case 3:
            Console.WriteLine("설정 메뉴로 이동합니다.");
            break;
        case 0:
            Console.WriteLine("게임을 종료합니다.");
            break;
        default:
            Console.WriteLine("잘못된 선택입니다.");
            break;
    }
} while (choice != 0);
```

### 3.2.4 foreach 문

`foreach` 문은 배열이나 컬렉션의 모든 요소를 순회할 때 사용하는 특별한 반복문으로, C#의 강력한 반복자(iterator) 패턴을 기반으로 합니다. 인덱스를 직접 관리할 필요가 없어 코드가 더 간결하고 읽기 쉬우며, 실수로 인한 오류(예: 인덱스 범위 초과, off-by-one error)를 원천적으로 방지할 수 있습니다.

**반복자 패턴과 IEnumerable의 이해:**

foreach 문은 `IEnumerable` 또는 `IEnumerable<T>` 인터페이스를 구현하는 모든 컬렉션에서 사용할 수 있습니다. 이는 디자인 패턴 중 반복자 패턴(Iterator Pattern)의 우아한 구현으로, 컬렉션의 내부 구조를 노출하지 않으면서도 순차적 접근을 제공합니다.

IEnumerable 인터페이스는 .NET의 컬렉션 프레임워크에서 핵심적인 역할을 합니다. 배열(Array), 리스트(List<T>), 딕셔너리(Dictionary<TKey, TValue>), 심지어 문자열(string)까지도 IEnumerable을 구현하여 foreach로 순회할 수 있습니다. 이는 통일된 인터페이스를 통해 다양한 데이터 구조를 일관된 방식으로 다룰 수 있게 해주는 다형성(polymorphism)의 좋은 예입니다.

**컴파일러의 변환 작업:**

흥미롭게도, foreach 문은 컴파일 시점에 GetEnumerator(), MoveNext(), Current를 사용하는 while 문으로 변환됩니다. 이는 foreach가 단순한 문법적 편의(syntactic sugar)를 넘어서, 컬렉션의 생명주기 관리(IDisposable을 통한 자원 해제)까지 자동으로 처리하는 강력한 추상화라는 것을 의미합니다.

**기본 구조:**

```csharp
foreach (타입 변수명 in 컬렉션)
{
    // 각 요소에 대해 실행될 코드
}
```

**배열 순회:**

```csharp
string[] fruits = { "사과", "바나나", "오렌지", "포도", "딸기" };

foreach (string fruit in fruits)
{
    Console.WriteLine(fruit);
}

// 출력:
// 사과
// 바나나
// 오렌지
// 포도
// 딸기
```

**for vs foreach 비교:**

```csharp
int[] numbers = { 1, 2, 3, 4, 5 };

// for 문 사용
Console.WriteLine("for 문:");
for (int i = 0; i < numbers.Length; i++)
{
    Console.WriteLine(numbers[i]);
}

// foreach 문 사용
Console.WriteLine("\nforeach 문:");
foreach (int number in numbers)
{
    Console.WriteLine(number);
}
```

**foreach의 장점과 트레이드오프:**

foreach 문의 주요 장점들은 소프트웨어 공학의 여러 원칙과 연결됩니다:

1. **추상화 수준 향상**: 인덱스라는 저수준 개념 대신 "각 요소에 대해"라는 고수준 개념으로 사고할 수 있습니다.
2. **가독성과 의도 명확성**: 코드를 읽는 사람에게 "모든 요소를 순회한다"는 의도를 즉각적으로 전달합니다.
3. **안전성**: 인덱스 범위 초과 오류(IndexOutOfRangeException)를 원천적으로 방지합니다.
4. **컬렉션 독립성**: 내부 구조(배열, 리스트, 트리 등)에 관계없이 동일한 방식으로 순회할 수 있습니다.

**foreach의 제약 사항과 그 이유:**

1. **읽기 전용 특성**: foreach의 반복 변수는 읽기 전용입니다. 이는 반복 중 컬렉션의 무결성을 보장하기 위한 의도적인 설계입니다. 만약 수정이 필요하다면, for 문을 사용하거나 LINQ의 Select()를 통해 새로운 컬렉션을 생성해야 합니다.
2. **단방향 순회**: foreach는 앞에서 뒤로만 순회하며, 역순 순회나 임의 건너뛰기가 어렵습니다. 이런 경우 for 문이 더 적합합니다.
3. **인덱스 부재**: 현재 요소의 인덱스가 필요하다면 별도로 카운터 변수를 유지하거나, LINQ의 Select((item, index) => ...) 같은 방법을 사용해야 합니다.

**var 키워드 사용:**

타입을 명시적으로 지정하는 대신 `var` 키워드를 사용하여 타입 추론을 활용할 수 있습니다.

```csharp
string[] cities = { "서울", "부산", "대구", "인천" };

foreach (var city in cities)
{
    Console.WriteLine(city);
}
```

**문자열 순회:**

문자열은 문자(`char`)의 시퀀스이므로 `foreach`로 순회할 수 있습니다.

```csharp
string text = "Hello";

foreach (char c in text)
{
    Console.WriteLine(c);
}

// 출력:
// H
// e
// l
// l
// o
```

**리스트 순회:**

```csharp
List<int> scores = new List<int> { 85, 92, 78, 95, 88 };

int sum = 0;
foreach (int score in scores)
{
    sum += score;
}

double average = (double)sum / scores.Count;
Console.WriteLine($"평균 점수: {average}");

// 출력: 평균 점수: 87.6
```

**중첩된 foreach:**

2차원 배열이나 컬렉션의 컬렉션을 순회할 때 중첩된 `foreach`를 사용할 수 있습니다.

```csharp
int[][] jaggedArray = new int[][]
{
    new int[] { 1, 2, 3 },
    new int[] { 4, 5 },
    new int[] { 6, 7, 8, 9 }
};

foreach (int[] innerArray in jaggedArray)
{
    foreach (int number in innerArray)
    {
        Console.Write(number + " ");
    }
    Console.WriteLine();
}

// 출력:
// 1 2 3
// 4 5
// 6 7 8 9
```

---

## 3.3 분기문

분기문은 프로그램의 정상적인 순차 실행 흐름을 변경하는 특별한 제어문으로, 구조적 프로그래밍(structured programming)의 핵심 요소입니다. 반복문 내에서 특정 조건에 따라 반복을 중단하거나 다음 반복으로 건너뛰고, 함수에서 값을 반환하면서 즉시 종료하는 등의 섬세한 흐름 제어가 필요할 때 사용합니다.

**구조적 프로그래밍과 분기문의 역할:**

1960년대 에츠허르 다익스트라(Edsger Dijkstra)의 "Go To Statement Considered Harmful" 논문 이후, 프로그래밍 언어들은 무분별한 goto 문 대신 구조화된 제어 흐름을 제공하는 방향으로 진화했습니다. C#의 분기문(`break`, `continue`, `return`)은 이러한 구조적 프로그래밍 원칙을 따르면서도, 필요한 곳에서 효율적인 흐름 제어를 가능하게 하는 절충안입니다.

C#의 주요 분기문으로는 `break`, `continue`, `return`이 있으며, 각각 명확한 목적과 사용 영역이 정의되어 있어 코드의 의도를 분명히 표현할 수 있습니다.

### 3.3.1 break

`break` 문은 현재 실행 중인 반복문이나 `switch` 문을 **즉시 종료**하고 그 다음 문장으로 제어를 이동시킵니다. 이는 조기 종료(early exit) 패턴의 구현으로, 특정 조건이 충족되었을 때 더 이상 반복할 필요가 없는 경우에 사용하여 불필요한 연산을 줄이고 효율성을 높일 수 있습니다.

**알고리즘 최적화 관점에서의 break:**

break 문은 단순한 편의 기능이 아니라 알고리즘의 시간 복잡도를 개선하는 중요한 도구입니다. 예를 들어, 배열에서 특정 요소를 찾는 선형 검색(linear search) 알고리즘에서 break를 사용하면 평균 성능을 크게 향상시킬 수 있습니다. 이는 "최선의 경우(best case)"와 "평균 경우(average case)"의 시간 복잡도를 개선하는 효과가 있습니다.

**기본 사용:**

```csharp
// 1부터 10까지 출력하되, 5를 만나면 중단
for (int i = 1; i <= 10; i++)
{
    if (i == 5)
    {
        Console.WriteLine("5를 발견했습니다. 반복을 중단합니다.");
        break;
    }
    Console.WriteLine(i);
}

// 출력:
// 1
// 2
// 3
// 4
// 5를 발견했습니다. 반복을 중단합니다.
```

**검색 작업에서의 활용:**

배열이나 컬렉션에서 특정 요소를 찾았을 때 더 이상 검색할 필요가 없으므로 `break`를 사용하여 효율성을 높입니다.

```csharp
string[] names = { "김철수", "이영희", "박민수", "최지혜", "정다은" };
string searchName = "박민수";
bool found = false;

foreach (string name in names)
{
    if (name == searchName)
    {
        Console.WriteLine($"{searchName}를 찾았습니다!");
        found = true;
        break;  // 찾았으므로 더 이상 검색할 필요 없음
    }
}

if (!found)
{
    Console.WriteLine($"{searchName}를 찾을 수 없습니다.");
}

// 출력: 박민수를 찾았습니다!
```

**while 반복문에서의 break:**

```csharp
int password = 1234;
int attempts = 0;
int maxAttempts = 3;

while (attempts < maxAttempts)
{
    Console.Write("비밀번호를 입력하세요: ");
    int input = int.Parse(Console.ReadLine());
    attempts++;
    
    if (input == password)
    {
        Console.WriteLine("로그인 성공!");
        break;  // 성공했으므로 반복 종료
    }
    
    Console.WriteLine($"비밀번호가 틀렸습니다. ({maxAttempts - attempts}번 남음)");
}

if (attempts == maxAttempts)
{
    Console.WriteLine("시도 횟수 초과. 계정이 잠겼습니다.");
}
```

**중첩된 반복문에서의 break와 제어 범위:**

`break` 문은 가장 안쪽의 반복문만 종료한다는 중요한 특성이 있습니다. 바깥쪽 반복문은 계속 실행됩니다. 이는 C#이 구조적 프로그래밍의 원칙을 따르면서도 명확한 제어 범위(scope of control)를 유지하도록 설계되었기 때문입니다.

```csharp
for (int i = 1; i <= 3; i++)
{
    Console.WriteLine($"외부 반복문: {i}");
    
    for (int j = 1; j <= 5; j++)
    {
        if (j == 3)
        {
            Console.WriteLine("  내부 반복문 중단");
            break;  // 내부 반복문만 종료
        }
        Console.WriteLine($"  내부 반복문: {j}");
    }
}

// 출력:
// 외부 반복문: 1
//   내부 반복문: 1
//   내부 반복문: 2
//   내부 반복문 중단
// 외부 반복문: 2
//   내부 반복문: 1
//   내부 반복문: 2
//   내부 반복문 중단
// 외부 반복문: 3
//   내부 반복문: 1
//   내부 반복문: 2
//   내부 반복문 중단
```

**다중 루프 탈출 전략:**

여러 중첩된 반복문을 한 번에 탈출해야 한다면, C#에는 레이블을 가진 break가 없으므로 다음과 같은 우회 전략을 사용합니다:
1. **플래그 변수 사용**: boolean 변수로 탈출 조건을 표시
2. **메서드 분리**: 중첩 루프를 별도 메서드로 추출하고 `return` 사용
3. **예외 처리**: 극단적인 경우 예외를 던져 탈출 (비권장)

두 번째 방법인 메서드 분리는 코드의 재사용성과 가독성을 높이는 리팩토링 기법으로도 권장됩니다.

### 3.3.2 continue

`continue` 문은 반복문의 **현재 반복을 즉시 종료**하고 다음 반복으로 건너뜁니다. `break`와 달리 반복문 자체를 종료하지 않고, 현재 반복의 나머지 코드를 건너뛰고 다음 반복을 계속 진행합니다. 이는 필터링(filtering) 패턴을 구현하는 우아한 방법으로, 특정 조건의 요소를 처리하지 않고 건너뛰고 싶을 때 매우 유용합니다.

**코드 평탄화와 조기 필터링:**

continue 문은 "보호 절(guard clause)" 패턴의 반복문 버전으로 볼 수 있습니다. 처리하고 싶지 않은 케이스를 먼저 걸러냄으로써, 메인 로직의 중첩 깊이를 줄이고 가독성을 향상시킵니다. 이는 소프트웨어 공학에서 말하는 "긍정적인 경로(happy path)"를 명확히 하는 기법입니다.

**기본 사용:**

```csharp
// 1부터 10까지의 숫자 중 홀수만 출력
for (int i = 1; i <= 10; i++)
{
    if (i % 2 == 0)
    {
        continue;  // 짝수는 건너뜀
    }
    Console.WriteLine(i);
}

// 출력:
// 1
// 3
// 5
// 7
// 9
```

**특정 조건 제외하기:**

```csharp
string[] words = { "사과", "바나나", "", "오렌지", null, "포도" };

foreach (string word in words)
{
    if (string.IsNullOrEmpty(word))
    {
        continue;  // null이나 빈 문자열은 건너뜀
    }
    Console.WriteLine(word);
}

// 출력:
// 사과
// 바나나
// 오렌지
// 포도
```

**continue vs if-else 비교:**

`continue`를 사용하면 중첩된 if 문을 줄이고 코드를 더 평탄하게(flat) 만들 수 있습니다.

```csharp
// if-else 사용 (중첩됨)
for (int i = 1; i <= 5; i++)
{
    if (i != 3)
    {
        Console.WriteLine($"처리 중: {i}");
    }
}

// continue 사용 (평탄함)
for (int i = 1; i <= 5; i++)
{
    if (i == 3)
    {
        continue;
    }
    Console.WriteLine($"처리 중: {i}");
}
```

**데이터 검증에서의 활용:**

```csharp
int[] scores = { 85, -5, 92, 150, 78, 95 };

Console.WriteLine("유효한 점수 목록:");
foreach (int score in scores)
{
    // 0~100 범위를 벗어난 점수는 무시
    if (score < 0 || score > 100)
    {
        Console.WriteLine($"  [경고] 잘못된 점수: {score}");
        continue;
    }
    Console.WriteLine($"  {score}점");
}

// 출력:
// 유효한 점수 목록:
//   85점
//   [경고] 잘못된 점수: -5
//   92점
//   [경고] 잘못된 점수: 150
//   78점
//   95점
```

**while 반복문에서의 continue:**

```csharp
int count = 0;

while (count < 10)
{
    count++;
    
    if (count % 3 == 0)
    {
        continue;  // 3의 배수는 출력하지 않음
    }
    
    Console.WriteLine(count);
}

// 출력: 1, 2, 4, 5, 7, 8, 10
```

### 3.3.3 return

`return` 문은 현재 실행 중인 **메서드(함수)를 즉시 종료**하고 호출한 곳으로 제어를 반환하는 문장으로, 함수의 결과값을 전달하는 동시에 실행 흐름을 변경하는 이중의 역할을 수행합니다. 값을 반환하는 메서드의 경우 `return` 뒤에 반환할 값을 명시하며, `void` 메서드의 경우 값 없이 `return`만 사용하여 메서드를 조기 종료할 수 있습니다.

**return 문의 의미론적 역할:**

return 문은 단순한 제어 흐름 변경을 넘어서, 함수형 프로그래밍의 핵심 개념인 "값으로서의 함수(function as value)"를 구현하는 메커니즘입니다. 메서드는 입력을 받아 계산을 수행하고 결과를 반환하는 "블랙박스"로 추상화되며, return은 이 블랙박스의 출구 역할을 합니다.

C#에서 return의 특징:
- **타입 안정성**: 반환 타입이 메서드 시그니처와 일치해야 하며, 컴파일러가 이를 검증합니다.
- **도달 가능성 분석**: 모든 실행 경로가 값을 반환하는지 컴파일 시점에 검사합니다(void 제외).
- **조기 종료 메커니즘**: 복잡한 조건 검사를 단순화하는 "조기 반환(early return)" 패턴을 지원합니다.

**기본 사용 (File-based App에서):**

File-based App에서는 별도의 메서드 선언 없이 최상위 문(Top-level statements)을 사용하므로, `return`은 프로그램 전체를 종료하는 효과를 가집니다.

```csharp
Console.WriteLine("프로그램 시작");

string input = Console.ReadLine();

if (string.IsNullOrEmpty(input))
{
    Console.WriteLine("입력이 없습니다. 프로그램을 종료합니다.");
    return;  // 프로그램 종료
}

Console.WriteLine($"입력: {input}");
Console.WriteLine("프로그램 계속 실행 중...");
```

**로컬 함수에서의 return:**

File-based App 내에서 로컬 함수를 정의하고 사용할 수 있으며, 여기서 `return`은 해당 함수만 종료합니다.

```csharp
// 로컬 함수 정의
int Add(int a, int b)
{
    return a + b;  // 계산 결과를 반환
}

int Divide(int a, int b)
{
    if (b == 0)
    {
        Console.WriteLine("0으로 나눌 수 없습니다.");
        return 0;  // 오류 시 기본값 반환
    }
    return a / b;
}

// 함수 호출
int sum = Add(10, 5);
Console.WriteLine($"합계: {sum}");  // 출력: 합계: 15

int result = Divide(10, 0);
Console.WriteLine($"나눗셈 결과: {result}");  // 출력: 나눗셈 결과: 0
```

**조기 반환 패턴 (Early Return Pattern):**

조건을 먼저 검사하여 유효하지 않은 경우 즉시 반환하는 패턴입니다. 이는 중첩된 if 문을 줄이고 코드의 가독성을 높이는 중요한 리팩토링 기법으로, "보호 절(guard clauses)" 또는 "경계 조건 우선 처리(boundary condition first)"라고도 불립니다.

**조기 반환의 장점:**
1. **중첩 감소**: 깊은 중첩을 제거하여 코드의 순환 복잡도(cyclomatic complexity)를 낮춥니다.
2. **의도 명확화**: 예외 케이스와 정상 케이스가 명확히 구분됩니다.
3. **오류 처리 개선**: 오류 조건을 먼저 처리하므로 방어적 프로그래밍에 유리합니다.

이 패턴은 Robert C. Martin의 "Clean Code"를 비롯한 여러 코딩 모범 사례 가이드에서 권장하는 기법입니다.

```csharp
string ValidateUser(string username, string password)
{
    // 조건을 먼저 검사하고 조기 반환
    if (string.IsNullOrEmpty(username))
    {
        return "사용자명을 입력하세요.";
    }
    
    if (string.IsNullOrEmpty(password))
    {
        return "비밀번호를 입력하세요.";
    }
    
    if (password.Length < 8)
    {
        return "비밀번호는 8자 이상이어야 합니다.";
    }
    
    // 모든 검증 통과 - "happy path"
    return "로그인 성공";
}

Console.WriteLine(ValidateUser("user", "1234"));      // 출력: 비밀번호는 8자 이상이어야 합니다.
Console.WriteLine(ValidateUser("user", "12345678")); // 출력: 로그인 성공
```

**반복문 내에서의 return과 범위:**

반복문 내에서 `return`을 사용하면 반복문뿐만 아니라 메서드 전체가 종료됩니다. 이는 `break`보다 강력한 탈출 메커니즘으로, 특히 검색이나 조건 만족 여부를 확인하는 함수에서 매우 유용합니다.

```csharp
bool ContainsNegative(int[] numbers)
{
    foreach (int num in numbers)
    {
        if (num < 0)
        {
            return true;  // 음수를 찾으면 즉시 true 반환하고 함수 종료
        }
    }
    return false;  // 모든 요소를 확인했는데 음수가 없으면 false 반환
}

int[] data1 = { 1, 2, 3, 4, 5 };
int[] data2 = { 1, -2, 3, 4, 5 };

Console.WriteLine(ContainsNegative(data1));  // 출력: False
Console.WriteLine(ContainsNegative(data2));  // 출력: True
```

**void 메서드에서의 return:**

반환값이 없는 메서드에서도 `return`을 사용하여 조기 종료할 수 있습니다.

```csharp
void PrintGrade(int score)
{
    if (score < 0 || score > 100)
    {
        Console.WriteLine("잘못된 점수입니다.");
        return;  // 메서드 조기 종료 (값 반환 없음)
    }
    
    if (score >= 90)
    {
        Console.WriteLine("A학점");
    }
    else if (score >= 80)
    {
        Console.WriteLine("B학점");
    }
    else if (score >= 70)
    {
        Console.WriteLine("C학점");
    }
    else
    {
        Console.WriteLine("F학점");
    }
}

PrintGrade(150);  // 출력: 잘못된 점수입니다.
PrintGrade(85);   // 출력: B학점
```

**break vs continue vs return 비교:**

| 구분 | break | continue | return |
|------|-------|----------|--------|
| 효과 | 반복문 종료 | 현재 반복 건너뜀 | 메서드/프로그램 종료 |
| 범위 | 가장 안쪽 반복문 | 가장 안쪽 반복문 | 전체 메서드 |
| 반환값 | 없음 | 없음 | 있을 수 있음 |
| 사용 위치 | 반복문, switch | 반복문만 | 어디서나 |

---

## 마무리

이 장에서는 C# 프로그래밍의 핵심인 제어문에 대해 깊이 있게 학습했습니다. 조건문(`if`, `else if`, `else`, `switch`)을 통해 프로그램이 상황에 따라 다르게 동작하도록 만들고, 반복문(`for`, `while`, `do-while`, `foreach`)을 통해 반복적인 작업을 효율적으로 처리하며, 분기문(`break`, `continue`, `return`)을 통해 실행 흐름을 세밀하게 제어하는 방법을 익혔습니다.

제어문은 단순해 보이지만, 이들을 적절히 조합하면 매우 복잡한 로직도 명확하게 표현할 수 있습니다. 다음 장에서는 데이터를 효율적으로 관리하고 처리하는 배열과 컬렉션에 대해 학습하게 될 것입니다. 지금까지 배운 제어문 지식은 앞으로 배울 모든 개념의 기초가 되므로, 충분히 연습하여 자유자재로 활용할 수 있도록 하세요.

**학습 정리:**

✅ **조건문 마스터**: `if`, `else if`, `else`, `switch` 문과 최신 switch 식을 활용한 조건 분기
✅ **반복문 활용**: `for`, `while`, `do-while`, `foreach` 문의 특성과 사용 시나리오 이해
✅ **분기문 제어**: `break`, `continue`, `return` 문을 통한 실행 흐름 제어
✅ **패턴 매칭**: C#의 강력한 패턴 매칭 기능을 활용한 현대적 코드 작성

**다음 단계:**

4장에서는 여러 데이터를 하나의 구조로 관리하는 배열에 대해 학습하고, 5장에서는 더욱 강력하고 유연한 컬렉션(List, Dictionary 등)을 다루게 됩니다. 제어문과 데이터 구조를 조합하면 실용적인 프로그램을 작성할 수 있는 기반이 완성됩니다.
